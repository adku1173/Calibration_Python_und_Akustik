"""Turntable control script for Outline ET2."""

import asyncio
from time import sleep

import typer
from rich.prompt import FloatPrompt, Prompt
from typer import Exit

from tapy.core.logger import CONSOLE
from tapy.devices.actuators import OutlineET2
from tapy_cli.console import option_select


def move_turntable(turntable, speed):
    while True:
        angle = FloatPrompt.ask('Enter angle', console=CONSOLE)
        asyncio.run(turntable.move(angle, speed=speed))


def tt_dwim():
    turntable = OutlineET2()
    options = {
        'B': {'description': 'Configure Backlash Compensation', 'available': True},
        'D': {'description': 'Configure Move Direction', 'available': True},
        'M': {'description': 'Move', 'available': True},
        'H': {'description': 'Homing', 'available': True},
    }
    while True:
        sleep(0.1)
        try:
            option = option_select(options)
        except KeyboardInterrupt:
            break
        try:
            if option == 'B':
                bc = Prompt.ask('Select Mode', choices=['cw', 'ccw', 'off'])
                turntable.blc = bc
            if option == 'D':
                td = Prompt.ask('Select Mode', choices=['shortest', 'cw', 'ccw'])
                turntable.turn_direction = td
            elif option == 'M':
                while True:
                    speed = FloatPrompt.ask('Please set move speed (between 0.4 and 1.0)', default=0.4)
                    if 0.4 <= speed <= 1:
                        move_turntable(turntable, speed)
                        break
                    else:
                        CONSOLE.print('Invalid value.')
            elif option == 'H':
                while True:
                    homing_speed = FloatPrompt.ask('Please set homing speed (between 0.4 and 1.0)', default=0.4)
                    if 0.4 <= homing_speed <= 1:
                        turntable.homing_speed = homing_speed
                        asyncio.run(turntable.homing())
                        break
                    else:
                        CONSOLE.print('Invalid value.')
            elif option == 'Q':
                break
            else:
                CONSOLE.print('Invalid option. Please try again.')
                continue
        except KeyboardInterrupt:
            CONSOLE.print('\nLeaving submenu ...')
    CONSOLE.print('Exiting ...')
    Exit()


def main():
    typer.run(tt_dwim)
