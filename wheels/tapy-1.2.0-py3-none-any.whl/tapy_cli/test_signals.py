"""Play noise on a sinus device."""

from typing import Annotated

import numpy as np
import typer
from typer import Exit, Option

from tapy.core.logger import CONSOLE


def play_noise(output, duration=5, repetitions=1):
    noise = np.random.randn(int(output.fs * duration))
    try:
        for _ in range(repetitions):
            with CONSOLE.status('[bold green]Playing noise ...'):
                with output.play(noise) as play:
                    pass
    except KeyboardInterrupt as ex:
        CONSOLE.print('\nStopping ...')
        play.stop()
        raise ex


def pn_dwim(sinus_ini: Annotated[str, Option()] = None):
    try:
        from tapy_cli.utils import get_sinus_device

        output = get_sinus_device(sinus_ini=sinus_ini)
        while True:
            play_noise(output)
    except KeyboardInterrupt:
        CONSOLE.print('\nExiting ...')
        Exit()


def main():
    typer.run(pn_dwim)
