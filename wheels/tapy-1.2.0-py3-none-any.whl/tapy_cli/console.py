"""Console utilities for TAPy-CLI scripts."""

from rich.prompt import Prompt

from tapy.core.logger import CONSOLE


def highlight_description(option, description):
    x = description.split(option, 1)
    return f'{x[0]}[bold yellow]{option}[/bold yellow]{x[1]}' if len(x) == 2 else x[0]


def option_select(opts):
    CONSOLE.print('Please select an option:')
    opts['Q'] = {'description': 'Quit', 'available': True}
    for option, vals in opts.items():
        description = highlight_description(option, vals['description'])
        style = 'green' if vals['available'] else 'red'
        CONSOLE.print(f'[{option}] : {description}', style=style)
    return Prompt.ask('Enter option: ', choices=[k for k, v in opts.items() if v['available']], console=CONSOLE)
