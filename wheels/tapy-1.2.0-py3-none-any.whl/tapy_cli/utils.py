"""Helper functions for TAPy-CLI scripts."""

from pathlib import Path

from tapy.core.config import config
from tapy.core.logger import CONSOLE


def get_sinus_device(sinus_ini=None):
    if sinus_ini is not None:
        assert Path(sinus_ini).exists()

    if config.HOSTNAME == 'tornado':
        from tapy.devices.sinus import Tornado

        return Tornado(config=sinus_ini)
    elif config.HOSTNAME == 'typhoon':
        from tapy.devices.sinus import Typhoon

        return Typhoon(config=sinus_ini)
    else:
        CONSOLE.print('No input detected.')
