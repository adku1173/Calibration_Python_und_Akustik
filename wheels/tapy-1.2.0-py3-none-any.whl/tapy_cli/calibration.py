"""Script for the calibration of microphones on a Sinus device."""

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.pretty import pprint
from rich.prompt import FloatPrompt, IntPrompt, Prompt
from typer import Exit, Option

from tapy.core.logger import CONSOLE


def calibrate_sensors(input, file='sensitivity.json'):
    if Path(file).exists():
        CONSOLE.print(f'Reading calibration values from "{file}".')
        with open(file) as f:
            calibdata = json.load(f)['sensitivity']
        pprint(dict(zip(range(1, len(calibdata) + 1), calibdata, strict=False)), console=CONSOLE)
        for ch, cal in zip(input.analog_inputs, calibdata, strict=False):
            ch.sensitivity = cal

    while True:
        CONSOLE.rule('Calibration configuration')
        sensor_kind = Prompt.ask(
            'Enter sensor type', default='microphone', choices=['microphone', 'force sensor'], console=CONSOLE
        )
        match sensor_kind:
            case 'microphone':
                calibvalue = FloatPrompt.ask('Enter calibration value \\[dBSPL]', default=94.0, console=CONSOLE)
                calibvalue = 2 * 1e-5 * 10 ** (calibvalue / 20)
                freq = FloatPrompt.ask('Enter calibration frequency \\[Hz]', default=1000.0, console=CONSOLE)
            case 'force sensor':
                calibvalue = FloatPrompt.ask('Enter calibration value \\[N]', console=CONSOLE)
                freq = FloatPrompt.ask('Enter calibration frequency \\[Hz]', default=159.2, console=CONSOLE)
        calibtime = FloatPrompt.ask('Enter calibration length \\[s]', default=4.0, console=CONSOLE)
        numsamples = int(calibtime * input.fs)

        try:
            while True:
                ch = IntPrompt.ask('Enter channel number', console=CONSOLE)
                channel = input.analog_inputs[ch - 1]
                with CONSOLE.status(f'[bold green]Calibrating channel {ch} ...', spinner='monkey'):
                    input.calibrate(channel=channel, calibvalue=calibvalue, f=freq, numsamples=numsamples)
                if hasattr(channel, 'TEDSData'):
                    channel.logger.info(f'manufacturer sensitivity: {channel.TEDSData["SensorSensitivity"]}')
                CONSOLE.print(f'sensitivity: {channel.sensitivity} for channel {ch}')
                with open(file, 'w') as f:
                    json.dump({'sensitivity': [ch.sensitivity for ch in input.analog_inputs]}, f)
        except KeyboardInterrupt:
            CONSOLE.print('\nBack to calibration configuration. Press Ctrl+C again to exit script.', style='yellow')


def cm_dwim(sinus_ini: Annotated[str, Option()] = None, file: Annotated[str, Option()] = 'sensitivity.json'):
    try:
        from tapy_cli.utils import get_sinus_device

        input = get_sinus_device(sinus_ini=sinus_ini)
        calibrate_sensors(input, file=file)
    except KeyboardInterrupt:
        CONSOLE.print('\nExiting ...')
        Exit()


def main():
    typer.run(cm_dwim)
