"""Contains classes for handling signal output."""

import asyncio
from abc import abstractmethod
from contextlib import contextmanager

import numpy as np
from traits.api import CArray, Dict, Float, Int, Property, Str

from tapy.core.base import BasicObject
from tapy.core.config import config
from tapy.core.connect import FastAPIObject
from tapy.core.logger import PROGRESS_BAR
from tapy.drivers.serial import SerialCommunicationError, SerialObject, timed_retry


class AudioOutput(BasicObject):
    """Base class for audio output.

    Base class for audio output usage. It includes an `fs` attribute for the sample rate
    of the audio signal, and an abstract `play` method that must be implemented by
    subclasses.


    Parameters
    ----------
    fs : float
        The sample rate of the audio signal, in Hz.
    name : str, optional
        The name of the object. This will be used for logging purposes.


    Attributes
    ----------
    fs : float
        The sample rate of the audio signal, in Hz.

    """

    fs = Float

    def __init__(self, fs, name=None):
        super().__init__(name)
        self.fs = fs

    @abstractmethod
    def play(self, signal):
        """Play an audio signal.

        This method must be implemented by subclasses.
        It should take an audio signal and output it through an audio device.


        Parameters
        ----------
        signal : ndarray
            The audio signal to play, as a 1D or 2D numpy array.


        Returns
        -------
        None

        """


if config.HAVE_SOUNDDEVICE:
    from sounddevice import check_output_settings, play

    class SDAudioOutput(AudioOutput):
        """Audio output using the `sounddevice` library.

        This class provides audio output functionality using the `sounddevice` library.
        It includes an :attr:`sd_settings` attribute for storing the output settings to use
        with `sounddevice`, and a :meth:`play` method that plays an audio signal using :meth:`sounddevice.play`.


        Example
        -------
        Samplerate and number of channels of the desired hardware device
        must be queried with the `sounddevice` library.
        To create an instance of :class:`SDAudioOutput` you can do the following:

        >>> import sounddevice as sd
        >>>
        >>> print(sd.query_devices())  # query device
        >>> output = SDAudioOutput(device=0, fs=48000, channels=2)


        Parameters
        ----------
        fs : float
            The sample rate of the audio signal, in Hz.
        name : str, optional
            The name of the object. This will be used for logging purposes.
        sd_settings : dict
            Additional output settings to pass to :meth:`sounddevice.play`.


        Attributes
        ----------
        sd_settings : dict
            Additional output settings to pass to :meth:`sounddevice.play`.

        """

        sd_settings = Dict(key_trait=Str)

        def __init__(self, fs, name=None, **sd_settings):
            super().__init__(fs, name=name)
            sd_settings['samplerate'] = fs
            with self.logger.info('Initializing ...'):
                with self.logger.info('Checking output settings ...'):
                    check_output_settings(**sd_settings)
                self.sd_settings = sd_settings

        @contextmanager
        def play(self, signal):
            """Play an audio signal using `sounddevice.play`.

            Parameters
            ----------
            signal : ndarray
                The audio signal to play, as a 1D or 2D numpy array.
            """
            with self.logger.info('Playing signal ...'):
                play(signal, blocking=True)


class OutlineET2(FastAPIObject):
    def __init__(self):
        super().__init__(*config.SERVERS['turntable'].values(), 'turntable')

    async def move(self, angle, speed=0.4):
        self.logger.info(f'Moving to {angle}°')
        with PROGRESS_BAR:
            cpos = self.position
            total = abs(cpos - angle)
            task = PROGRESS_BAR.add_task(f'{self.name}: Moving to {angle}°', total=total)
            future = asyncio.create_task(self.move_no_progress(angle, speed=speed))
            while not future.done():
                lpos, cpos = cpos, self.position
                PROGRESS_BAR.update(task, advance=abs(cpos - lpos))
                await asyncio.sleep(0.5)
            PROGRESS_BAR.update(task, complete=total)
            PROGRESS_BAR.remove_task(task)


class BlackBoxX32RuntimeError(Exception):
    """Raised if the BlackBoxX32 device is requested but not idle."""


class BlackBoxX32AlarmError(BlackBoxX32RuntimeError):
    """Raised if the BlackBox is in a state of alarm."""


class BlackBoxX32(SerialObject):
    """Driver class for the BlackBoxX32 device.

    This class talkes to the GRBL driver via a serial port.

    Parameters
    ----------
    mode : str, optional
        The mode of operation, depends on the connected hardware. Either '1d', '2d' or '3d'. The
        one-dimensional hardware should always be connected after the two-dimensional hardware, if
        using both. Note that the blackbox supports only three idependent axes (Y2 is a mirror of Y).
    port : str, optional
        The serial port name.
    homing : bool
        Whether or not the system should be homed when instantiating. Defaults to True.
    maxtries : int, optional
        The number of times a failed serial communication is repeated. Defaults to 5.
    maxtime : float, optional
        The maximum time in seconds that is waited for a successful serial communication.
        Defaults to 10.
    ex : numpy.ndarray
        X-axis basis vector for position calibration. If the traverse movement axes are not
        perfectly orthogonal, this can be used for compensation. Defaults to None.
    ey : numpy.ndarray
        See `ex`.
    ez : numpy.ndarray
        See `ex`.
    name : str, optional
        The name of the device (if not specified, it will be determined automatically at initialization).
    """

    origin = CArray
    machine_position = Property
    coordinate_systems = Property
    retries = Int
    dim = Int
    _coomap = CArray
    _working_position = CArray

    def __init__(
        self, mode, port='/dev/ttyUSB0', homing=True, maxtries=5, maxtime=5, ex=None, ey=None, ez=None, name=None
    ):
        assert mode in ('1d', '2d', '3d')
        super().__init__(port=port, name=name, baudrate=115200)
        with self.logger.info('Initializing ...'):
            self.maxtries = maxtries
            self.maxtime = maxtime
            self.dim = int(mode[0])
            self.calibrate_axes(x=ex, y=ey, z=ez)
            self._working_position = np.zeros(self.dim)
            asyncio.run(self._query_status())  # ensure device is not in Alarm state
            asyncio.run(self._send_gcode('G21'))  # use mm
            if homing:
                asyncio.run(self.homing())

    async def homing(self):
        """Home the device."""
        if await self._is_idle():
            with self.logger.info('Homing X Axis ...'):
                await self._send_gcode('$H X')
            if self.dim > 1:
                with self.logger.info('Homing Y Axis ...'):
                    await self._send_gcode('$H Y')
            if self.dim == 3:
                with self.logger.info('Homing Z Axis ...'):
                    await self._send_gcode('$H Z')
        else:
            raise BlackBoxX32RuntimeError('Homing could not be executed. Device is not idle.')

    async def move(self, pos, gmode=0, feedrate=100, wcs=1):
        """Move the device to the specified position.

        Parameters
        ----------
        pos : numpy.ndarray of shape (self.dim,)
            The destination position in mm.
        gmode : int
            0 for rapid movement. 1 for `feedrate` defined speed. Defaults to 0.
        feedrate : int
            Defines the movement speed for `gmode=1`. Defaults to 100.
        wcs : int
            The coordinate system which defines the position `pos`. Defaults to 1.
        """
        wcs = self._resolve_wcs(wcs)
        pos = np.asarray(pos[: self.dim], dtype=float)
        if await self._is_idle():
            with self.logger.info(f'Moving to {pos} ...'):
                pos = self._coomap @ pos
                gcode = f'{wcs} G{gmode} {f"F{feedrate}" if feedrate is not None else ""} X{pos[0]}'
                if self.dim > 1:
                    gcode += f' Y{pos[1]}'
                if self.dim > 2:
                    gcode += f' Z{pos[3]}'
                cs = await self._get_coordinate_systems()
                await self._move(pos + cs[wcs], gcode, wcs)
        else:
            raise BlackBoxX32RuntimeError('Move command could not be executed. Device is not idle.')

    async def center_wcs_here(self, wcs=1):
        """Set the current machine position as the center of the coordinate system.

        Parameters
        ----------
        wcs : int
            The working coordinate system. Defaults to 1.
        """
        self.origin = await self._get_machine_position()
        wcs = await self._resolve_wcs(wcs)
        await self._send_gcode(f'G10 L20 {wcs} X0 Y0 Z0')
        msg = f'Set coordinate system {wcs} center position to: X{self.origin[0]} Y{self.origin[1]}'
        if self.dim == 3:
            msg += f' Z{self.origin[2]}'
        self.logger.info(msg)

    def calibrate_axes(self, x=None, y=None, z=None):
        """Calibrates the movement axes in case they are not perfectly orthogonal.

        Parameters
        ----------
        x : numpy.ndarray, optional
            Basis vector that maps the virtual x-direction to the real movement of the traverse.
        y : numpy.ndarray, optional
            Basis vector that maps the virtual y-direction to the real movement of the traverse.
        z : numpy.ndarray, optional
            Basis vector that maps the virtual z-direction to the real movement of the traverse.
        """
        match self.dim:
            case 1:
                x = np.array([1]) if x is None else np.asarray(x)
                self._coomap = x.reshape(1, 1)
            case 2:
                x = np.array([1, 0]) if x is None else np.asarray(x)
                y = np.array([0, 1]) if y is None else np.asarray(y)
                assert len(x) == len(y) == self.dim
                assert z is None
                self._coomap = np.vstack((x, y)).T
            case 3:
                x = np.array([1, 0, 0]) if x is None else np.asarray(x)
                y = np.array([0, 1, 0]) if y is None else np.asarray(y)
                z = np.array([0, 0, 1]) if z is None else np.asarray(z)
                assert len(x) == len(y) == len(z) == self.dim
                self._coomap = np.vstack((x, y, z)).T

    def save_current_position(self):
        """Save the current machine position on the device."""
        asyncio.run(self._send_gcode('G28.1'))

    async def move_to_saved_position(self):
        """Move to the saved position."""
        await self._send_gcode('G28')

    def stop(self):
        """Stop the device immediately with locking the motors.

        In GRBL, the "!" command is known as "feed hold"
        """
        asyncio.run(self._send_gcode('!'))

    def resume(self):
        """Resume the device after a stop command (GRBL status is 'Hold')."""
        asyncio.run(self._send_gcode('~'))

    def reset(self):
        """Reset the device (Ctrl+x)."""
        asyncio.run(self._send_gcode('\x18'))

    @timed_retry
    async def _send_gcode(self, gcode, pos=None):
        """Write a GCode command to the device.

        Interaction takes place with GRBL firmware.
        GRBL answers with response messages (include 'ok' or 'error')
        or push messages (placed in [] brackets, <> chevrons, start with a $,
        or a specific string of text)

        Parameters
        ----------
        gcode : str
            The GCode command to write.
        pos : numpy.ndarray
            A coordinate that will appended as GCode string. Defaults to None.
        """
        gcode = gcode.strip()  # Strip all EOL characters for consistency
        if pos is not None:
            gcode += f' X{pos[0]} Y{pos[1]} Z{pos[2]}'
        code = (gcode + '\n').encode()
        rstr = ''
        with self.logger.driver(f'Sending: {gcode}'):
            self.serial.write(code)
            await asyncio.sleep(0.2)  # crucial to prevent hangups
            while True:
                r = self.serial.readline().strip().decode()
                self.logger.driver(f'Receiving: {r}')
                if r in ['ok', 'error']:
                    break
                rstr += r
                rstr += '\n'
            if 'error' in r:
                raise SerialCommunicationError(f'GCode error: {rstr}.')
            return rstr

    async def _move(self, pos, gcode, wcs):
        """Move to the given position (in mm).

        Parameters
        ----------
        pos : CArray
            The position to move to.
        wcs : int
            The working coordinate system.
        """
        # use machine coordinates below
        cpos = await self._get_machine_position()
        dist = np.linalg.norm(cpos - pos)
        with PROGRESS_BAR:
            task = PROGRESS_BAR.add_task(f'{self.name}: Moving to {pos}', total=dist, start=False)
            await self._send_gcode(gcode)
            while True:
                PROGRESS_BAR.start_task(task)
                await asyncio.sleep(0.2)  # max 5 Hz GCode update rate
                lpos = cpos
                cpos = await self._get_machine_position()
                prog = np.linalg.norm(cpos - lpos)
                PROGRESS_BAR.update(task, advance=prog)
                # tolerance of the traverse is about 0.005 mm, the tolerance here only affects the progress bar
                if np.abs(prog) <= 1e-2:
                    break
            PROGRESS_BAR.remove_task(task)

    @timed_retry
    async def _query_status(self, return_string=False):
        """Query the device for its status.

        Device returns a string of the form:
        Status: <Run|MPos:191.992,0.000,0.000|Bf:34,1023|FS:500,0|Pn:PXYZ>

        Parameters
        ----------
        return_string : bool
            Whether to return the full answer string. Defaults to False.

        Returns
        -------
        status : str
            The grbl device status (Run / Idle / Hold /...).
        """
        with self.logger.driver('Querying Status ...'):
            with self._exception_handler():
                rstr = await self._send_gcode('?')
            if rstr.find('<') == -1:
                raise SerialCommunicationError(f'Unexpected answer: {rstr}.')
            status = rstr[rstr.find('<') + 1 : rstr.find('|')]
            self.logger.driver(f'Device status: {status}')
            if status == 'Alarm':
                self.logger.critical('Device is in ALARM state.')
                raise BlackBoxX32AlarmError('Alarm!')
            if return_string:
                return status, rstr
            else:
                return status

    @timed_retry
    async def _is_idle(self):
        status = await self._query_status()
        if status == 'Idle':
            return True
        else:
            raise SerialCommunicationError(f'Device is not Idle. Status: {status}')

    async def _get_machine_position(self):
        """Get the current machine position from the status string in mm."""
        with self.logger.driver('Querying machine position ...'):
            _, rstr = await self._query_status(return_string=True)
            pos = rstr[rstr.find('MPos:') + 5 : rstr.find('|Bf')].split(',')
            pos = np.array(pos[: self.dim]).astype(float)
            self.logger.driver(f'Machine position: {pos}')
            return pos

    async def _get_coordinate_systems(self):
        gcodes = await self._send_gcode('$#')
        coords = {}
        gcodes = gcodes.split('\n')
        for gcode in gcodes:
            if gcode.startswith('[G'):
                param, value = gcode.strip('[ ]').split(':')
                coords[param] = np.array(value.split(',')[: self.dim]).astype(float)
        return coords

    def _resolve_wcs(self, wcs):
        assert wcs in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
        if wcs < 7:
            return f'G{wcs + 53}'
        else:
            return f'G59.{wcs - 6}'
