"""High-level classes to communicate with Sinus devices (Apollo, Tornado, Typhoon)."""

import configparser

from traits.api import Bool, CArray, Dict, Either, Float, List, Str

from tapy.core.base import BasicObject


class SinusDevice(BasicObject):
    """Base class for higher level devices such as :class:`Apollo` and `:class:`Typhoon`.

    The class implements high-level routines, e.g. the :meth:`play` and :meth:`record` methods.
    """

    # we import inside the class to avoid circular imports and do lazy loading
    # otherwise, we would waste a lot of time importing sinus drivers that are not used
    # importing as private with underscore is needed for sphinx autosummary to work correctly
    from tapy.drivers.sinus import SinusADCToDACChannel as _SinusADCToDACChannel
    from tapy.drivers.sinus import SinusAnalogChannel as _SinusAnalogChannel
    from tapy.drivers.sinus import SinusPCICard as _SinusPCICard

    config = Either(Str, None)
    serials = List(str)
    sync_pci = Either(Bool, None)
    fs = Float
    pci = List(_SinusPCICard)
    analog_inputs = List(_SinusAnalogChannel)
    analog_outputs = List(_SinusAnalogChannel)
    adc_to_dac = List(_SinusADCToDACChannel)
    data = CArray

    # private attributes
    _settings = Dict
    _initialized = Bool(False)
    _instances = {}  # Dictionary to store singleton instances for each subclass

    def __new__(cls, *args, **kwargs):
        if cls not in cls._instances:
            # If no instance exists for the subclass, create one and store it
            cls._instances[cls] = super(SinusDevice, cls).__new__(cls)
        return cls._instances[cls]

    def __init__(self, serials, sync_pci=False, config=None, fs=None, name=None, **kwargs):
        if not self._initialized:
            from tapy.drivers.sinus import SinusPCICard as _SinusPCICard

            self.sync_pci = sync_pci
            self.serials = serials
            self.config = config
            super().__init__(name=name)
            self._initialized = True
            with self.logger.info('Initializing ...'):
                # read device config if given
                if self.config is not None:
                    self.logger.debug(f'Read channel settings from {self.config}.')
                    self.ini_import(level='Device')

                # initialize in reverse order to let master device initialize last and stay open
                for i, serial in reversed(list(enumerate(serials))):
                    settings = {'fs': fs}
                    if self._settings.get('Device') is not None:
                        settings.update({it: k[i] for it, k in self._settings['Device'].items()})
                    self.pci.insert(0, _SinusPCICard(serial, sync_order=serials if sync_pci else None, **settings))

                # expose the private channel attributes
                for pci in self.pci:
                    try:  # TODO: why try and except?
                        self.analog_inputs.extend(pci.__dict__['_SinusPCICard__analog_inputs'])
                    except KeyError:
                        pass
                    try:
                        self.analog_outputs.extend(pci.__dict__['_SinusPCICard__analog_outputs'])
                    except KeyError:
                        pass
                    try:
                        self.adc_to_dac.extend(pci.__dict__['_SinusPCICard__adc_to_dac'])
                    except KeyError:
                        pass

                if fs is None:
                    fs = float(self.analog_inputs[0].SampleRate)

                # rename channel attributes and set sampling rate
                for i, ai in enumerate(self.analog_inputs):
                    ai.name = f'AnalogInput_{i + 1:03d}'
                    ai.SampleRate = str(int(fs))
                    ai.set_settings('SampleRate')
                self.set_config_settings(level='AnalogInput')
                self.fs = float(self.analog_inputs[0].SampleRate)

                for i, ao in enumerate(self.analog_outputs):
                    ao.name = f'AnalogOutput_{i + 1:03d}'
                    ao.SampleRate = str(int(fs))
                    ao.set_settings('SampleRate')
                self.set_config_settings(level='AnalogOutput')

                for i, adc in enumerate(self.adc_to_dac):
                    adc.name = f'ADCToDAC_{i + 1:03d}'
                    adc.SampleRate = str(int(fs))
                    adc.set_settings('SampleRate')
                self.set_config_settings(level='ADCToDAC')

    def _get_device_index(self, device_index):
        if isinstance(self, Apollo):
            return 0
        elif (device_index is None) and (self.sync_pci is True):
            return self.pci[0].device_index
        elif (device_index is None) and (self.sync_pci is False):
            raise ValueError('device_index must be specified if sync_pci is False')
        else:
            return device_index

    def _prepare_channel_list(self, channels):
        from tapy.drivers.sinus import SinusAnalogChannel as _SinusAnalogChannel

        if channels[0] is int:
            channels = (slice(index) for index in channels)
        elif isinstance(channels[0], _SinusAnalogChannel):
            pass
        return channels

    def _validate_signal(self, numchannels, signal):
        if signal.ndim > 1:
            if not signal.shape[0] == numchannels:
                raise ValueError(f'signal must have {numchannels} dimensions but has {signal.shape[0]}')

    def play(self, signal, channels=None, on_cue=False, context=None, device_index=None):
        from tapy.drivers.sinus import SINUS_STREAM, SinusDeviceContext

        device_index = self._get_device_index(device_index)
        with SinusDeviceContext('Open', device_index):
            if channels is None:
                channels = self.analog_outputs
            channels = self._prepare_channel_list(channels)
            self._validate_signal(len(channels), signal)
            return SINUS_STREAM.play(signal, channels=channels, on_cue=on_cue, context=context)

    def record(self, channels=None, numsamples=None, on_cue=False, context=None, device_index=None):
        from tapy.drivers.sinus import SINUS_STREAM, SinusDeviceContext

        device_index = self._get_device_index(device_index)
        with SinusDeviceContext('Open', device_index):
            if channels is None:
                channels = self.analog_inputs
            channels = self._prepare_channel_list(channels)
            # TODO: pass self to record function
            return SINUS_STREAM.record(
                cal_obj=self, channels=channels, numsamples=numsamples, on_cue=on_cue, context=context
            )

    def calibrate(
        self, channel, calibvalue=1.0, f=1000.0, numsamples=None, on_cue=False, context=None, device_index=None
    ):
        from tapy.drivers.sinus import SINUS_STREAM, SinusDeviceContext

        device_index = self._get_device_index(device_index)
        with SinusDeviceContext('Open', device_index):
            channel = self._prepare_channel_list([channel])
            with SINUS_STREAM.calibrate(
                cal_obj=self,
                calibvalue=calibvalue,
                f=f,
                channel=channel,
                numsamples=numsamples,
                on_cue=on_cue,
                context=context,
            ):
                pass

    # TODO: implement play_rec that utilizes the stream context for easy usage

    @staticmethod
    def _interpret_ini(channel_num, val_string):
        """Convert INI string values of an attribute to list of attribute values on its corresponding channels.

        Parameters
        ----------
        channel_num : int
            The number of channels for a given attribute.
        val_string : str
            String value of settings


        Returns
        -------
        List(str)
            List of attribute values assigned to the corresponding channel number.
        """
        channel_values = [None] * channel_num

        if val_string.count('#') > 0:
            val_string = val_string.split('#')[0]  # only take string before comment sign

        workflow = val_string.split(',')
        workflow = [task.strip() for task in workflow]  # Turn into list of tasks

        if '@' in val_string or len(workflow) == 1:
            for task in workflow:
                if '@' in task:
                    val = task.split('@')[0]

                    ch_indices = (
                        task.split('@')[1].replace('[', '').replace(']', '').split(' ')
                    )  # Split channel indices
                    arr_indices = []

                    for index_str in ch_indices:
                        if '-' in index_str:  # Ranges of index into list of indices
                            for index in range(int(index_str.split('-')[0]) - 1, int(index_str.split('-')[1])):
                                arr_indices.append(index)
                        else:  # Single index
                            arr_indices.append(int(index_str) - 1)

                    for arr_idx in arr_indices:
                        channel_values[arr_idx] = val  # Assign each value to corresponding channel
                else:
                    channel_values = [task] * channel_num
        else:
            channel_values = workflow
        return channel_values

    def ini_import(self, level=None):
        """Import INI file to the setting dictionary. Needs to be set using set_settings().

        Parameters
        ----------
        ini_file : str
            Directory of ini file.
        """
        conf = configparser.RawConfigParser()
        conf.optionxform = lambda option: option  # Preserve case
        conf.read(self.config)

        num_channels = {
            'Device': len(self.serials),
            'AnalogInput': len(self.analog_inputs),
            'AnalogOutput': len(self.analog_outputs),
            'ADCToDAC': len(self.adc_to_dac),
        }

        levels = [s for s in conf.sections() if s in num_channels]
        if (level is not None) and (level in levels):
            levels = [level]
        elif (level is not None) and (level not in levels):
            return
        for level in levels:
            self._settings[level] = {}
            for attribute in conf[level].keys():
                self._settings[level][attribute] = self._interpret_ini(num_channels[level], conf[level][attribute])

    def set_config_settings(self, level=None):
        """Import and set settings."""
        # read device config if given
        if self.config is not None:
            self.logger.debug(f'Read channel settings from {self.config}.')
            self.ini_import(level=level)
        else:
            return

        msg = f'Setting settings from ini file {self.config}...'
        if level is not None:
            msg = f'Setting {level} settings from ini file {self.config} for {level}...'

        with self.logger.info(msg):
            if level is None:
                settings = self._settings.items()
            else:
                settings = [(level, self._settings.get(level))]
            for level, attributes in settings:
                if level == 'Device' and (self._settings.get('Device') is not None):
                    for attribute, value_list in attributes.items():
                        for idx, value in enumerate(value_list):
                            if value is not None:
                                setattr(self.pci[idx], attribute, value)
                                self.pci[idx].set_settings(attribute=attribute)

                elif level == 'AnalogInput' and (self._settings.get('AnalogInput') is not None):
                    for attribute, value_list in attributes.items():
                        for idx, value in enumerate(value_list):
                            if value is not None:
                                if attribute == 'sensitivity':
                                    value = float(value)
                                setattr(self.analog_inputs[idx], attribute, value)
                                if attribute != 'sensitivity':
                                    self.analog_inputs[idx].set_settings(attribute=attribute)

                elif level in ('ADCToDAC', 'AnalogOutput') and (self._settings.get(level) is not None):
                    for attribute, value_list in attributes.items():
                        for idx, value in enumerate(value_list):
                            if value is not None:
                                if level == 'AnalogOutput':
                                    setattr(self.analog_outputs[idx], attribute, value)
                                    self.analog_outputs[idx].set_settings(attribute=attribute)
                                else:
                                    setattr(self.adc_to_dac[idx], attribute, value)
                                    self.adc_to_dac[idx].set_settings(attribute=attribute)


class Apollo(SinusDevice):
    """
    Class that corresponds to the Apollo device.

    Can be instantiated using the inventory numbers 'TA181' or 'TA132'.

    >>> from tapy.devices.sinus import Apollo
    >>> apollo = Apollo('TA181')
    """

    def __init__(self, inventory_no, fs=None, config=None):
        from tapy.drivers.sinus import apollo_ta132_pci_serials, apollo_ta181_pci_serials

        apollo_pci_serials = {'TA132': apollo_ta132_pci_serials, 'TA181': apollo_ta181_pci_serials}[inventory_no]
        super().__init__(list(apollo_pci_serials), sync_pci=False, config=config, fs=fs, name='Apollo-' + inventory_no)


class Tornado(SinusDevice):
    """Class that corresponds to the Tornado device."""

    def __init__(self, fs=None, sync_pci=True, config=None):
        from tapy.drivers.sinus import tornado_pci_serials

        super().__init__(list(tornado_pci_serials), fs=fs, config=config, sync_pci=sync_pci)


class Typhoon(SinusDevice):
    """Class that corresponds to the Typhoon device."""

    def __init__(self, fs=None, sync_pci=True, config=None):
        from tapy.drivers.sinus import typhoon_pci_serials

        super().__init__(list(typhoon_pci_serials), fs=fs, config=config, sync_pci=sync_pci)
