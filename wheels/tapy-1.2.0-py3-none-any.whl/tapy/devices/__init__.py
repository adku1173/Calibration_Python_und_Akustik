"""Contains classes for every physical device in the TAP inventory.

Physical devices are split into two categories:
    1. :mod:`~tapy.devices.actuators`: Any device that takes an input and influences a physical
    quantity such as a loudspeaker in the form on an
    :mod:`audio output <tapy.devices.sensors.AudioOutput>` or a positioning device.
    2. :mod:`~tapy.devices.sensors`: Any device that measures a physical quantity such as a
    microphone in the form on an :mod:`audio input <tapy.devices.sensors.AudioInput>` or a
    temperature sensor.

.. autosummary::
   :toctree: generated/

    actuators
    sensors
    sinus
"""
