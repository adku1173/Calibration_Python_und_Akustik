"""Contains classes for handling signal input."""

from abc import abstractmethod
from contextlib import contextmanager
from queue import Queue

import numpy as np
from traits.api import CArray, Dict, Float, Str, Trait

from tapy.core.base import BasicObject
from tapy.core.config import config
from tapy.drivers.serial import SerialObject


class AudioInput(BasicObject):
    """Base class for audio input.

    This class provides a base implementation for audio input functionality.
    It includes the sample rate :attr:`fs` and the :attr:`data` attribute for storing
    providing the recorded audio data.The abstract :meth:`record` method must be
    implemented by subclasses.


    Parameters
    ----------
    fs : float
        The sample rate of the audio input device, in Hz.
    name : str, optional
        The name of the object. This will be used for logging purposes.

    Attributes
    ----------
    fs : float
        The sample rate of the audio signal, in Hz.
    data : numpy.ndarray
        The recorded audio data.
    """

    fs = Float
    data = CArray
    _queue = Trait(Queue)

    def __init__(self, fs, name=None):
        super().__init__(name)
        self.fs = fs

    def _get_data(self):
        return self._data.copy()

    def _set_data(self, data):
        self._data = data

    @abstractmethod
    def record(self):
        """Record audio.

        This method must be implemented by subclasses to provide audio recording functionality.

        """


if config.HAVE_SOUNDDEVICE:
    from sounddevice import InputStream, check_input_settings

    class SDAudioInput(AudioInput):
        """Audio input using sounddevice.

        This class provides audio input functionality using the `sounddevice` library. It includes :attr:`sd_settings`
        for the :class:`sounddevice.InputStream` object and a :meth:`record` method that allows audio
        to be recorded.

        Example
        -------
        Samplerate and number of channels of the desired hardware device
        must be queried with the `sounddevice` library.
        To create an instance of :class:`SDAudioInput` you can do the following:

        >>> import sounddevice as sd
        >>>
        >>> print(sd.query_devices())  # query device
        >>> input = SDAudioInput(device=0, fs=48000, channels=2)


        Parameters
        ----------
        fs : float
            The sample rate of the audio signal, in Hz.
        name : str, optional
            The name of the object. This will be used for logging purposes.
        **sd_settings
            Keyword arguments for the :class:`sounddevice.InputStream` constructor.


        Attributes
        ----------
        stream : sounddevice.InputStream
            The :class:`sounddevice.InputStream` instance used for recording audio.
        sd_settings : dict
            The sounddevice settings.

        """

        stream = Trait(InputStream)
        sd_settings = Dict(key_trait=Str)

        def __init__(self, fs, name=None, **sd_settings):
            super().__init__(fs, name=name)
            sd_settings['samplerate'] = fs
            with self.logger.info('Initializing ...'):
                with self.logger.info('Checking input settings ...'):
                    check_input_settings(**sd_settings)
                self.sd_settings = sd_settings

        @contextmanager
        def record(self):
            """Record audio using the `sounddevice` library.

            This method uses the :class:`sounddevice.InputStream` class to record audio,
            and yields control to the calling context while recording is in progress.
            When the calling context exits, recording is stopped and the recorded
            audio data is stored in the :attr:`data` attribute.

            """
            self._queue = Queue()  # empty the queue
            self.stream = InputStream(callback=self._stream_callback, **self.sd_settings)
            with self.logger.info('Recording signal ...'):
                self.logger.info('Starting stream ...')
                with self.stream:
                    try:
                        yield
                    except Exception as err:
                        self.logger.error(err)
                    finally:
                        self.logger.info('Stopping stream ...')
                self.data = np.concatenate(list(self._queue.queue), axis=0).T

        def _stream_callback(self, indata, frames, time, status):
            if status:
                self.logger.error(f'{status}')
            self._queue.put(indata.copy())


class MELTECSensor(SerialObject):
    """Base class for MELTEC serial temperature and humidity sensors.

    Parameters
    ----------
    port : str, optional
        The serial port name (e.g. /dev/ttyACM0). Default is None.

    Attributes
    ----------
    port : str
        The serial port name (e.g. /dev/ttyACM0)
    """

    def __init__(self, port=None, name=None):
        super().__init__(port=port, name=name)
        self.serial.timeout = 0.1
        self.name = self._identify()[0]

    def __str__(self):
        model, serial_no, firmware, manufacturer = self._identify()
        return (
            f'Serial Sensor:\nManufacturer:\t{manufacturer}\nModel:\t\t{model}\n'
            + f'Serial no.:\t{serial_no}\nFirmware:\tv.{firmware}'
        )

    def _identify(self):
        """
        Reads the sensor information.

        Returns
        -------
        model : str
            The sensor model.
        serial_no : str
            The serial number of the sensor.
        firmware : str
            The firmware version.
        manufacturer : str
            The manufacturer of the sensor.
        """
        with self._exception_handler():
            self.serial.write(bytearray([0, 255]))
            manufacturer, model, firmware = self.serial.readline()[2:-1].decode().split(' ')
            self.serial.write(bytearray([1, 254]))
            serial_no = self.serial.readline()[2:-1].decode()
            return model, serial_no, firmware, manufacturer

    def _read_data(self):
        """
        Reads the sensor data.

        Example: Sends the byte array [2,253]. Sensor returns byte string [253, 2, 0, 0, 144, 3, 192].
        253,2 -> answer on input string 2,253
        0,0 -> 16 Bit measurement data (humidity)
        144,3 -> 16 Bit measurement data (temperature)
        192 -> Flag Byte

        Returns
        -------
        data : list
            The data as a list of ints. Needs to be cast into the true values depending on the sensor.
        """
        self.serial.write(bytearray([2, 253]))
        try:
            return np.frombuffer(self.serial.readline()[2:6], dtype=np.uint16)
        except ValueError:
            self.logger.error('Failed to read sensor!')
            return [0, 0]

    def reset_usb(self):
        """
        Resets the USB connection.

        This method can be used to temporarily deconnect the sensor and execute a USB-reset of the
        sensor. It simulates a physical unplugging and plugging of the USB cable to the sensor.
        """
        self.serial.write(bytearray([119, 136]))


class OT60(MELTECSensor):
    """The driver class for the MELTEC OT60-B temperature sensor.

    The OT60-B Sensor is a USB sensor that measures the temperature in a range of -10°C to 60°C with
    a precision of +-.8°C.

    Parameters
    ----------
    port : str, optional
        The serial port name (e.g. /dev/ttyACM0). Default is None.

    Attributes
    ----------
    port : str
        The serial port name (e.g. /dev/ttyACM0)
    """

    def __init__(self, port=None, name=None):
        super().__init__(port=port)
        assert self.name == 'OT60-B'
        if name is not None:
            self.name = name

    def read_temperature(self):
        """
        Reads the current temperature.

        Returns
        -------
        float
            Temperature in °C.
        """
        return self._read_data()[1] * 70.0 / 2048.0 - 10.0


class OHT20(MELTECSensor):
    """The driver class for the MELTEC OHT20-A humidity and temperature sensor.

    The OT20-A Sensor is a USB sensor that measures the humidity at an accuracy of +- 1.5% at 25°C
    and the temperature in a range of -20°C to 50°C with a precision of +-.1°C and +-.3°C in a range
    of -55°C to 150°C. Repeatability 0.1% RH / +-0.08 °C.

    Note:
        The sensor may have an internal heating element to dry the humidity sensor. This feature is
        currently not implemented but could be done with simple serial communication
        (see MELTEC manual).

    Parameters
    ----------
    port : str, optional
        The serial port name (e.g. /dev/ttyACM0). Default is None.

    Attributes
    ----------
    port : str
        The serial port name (e.g. /dev/ttyACM0)
    """

    def __init__(self, port=None, name=None):
        super().__init__(port=port)
        assert self.name == 'OHT20-A'
        if name is not None:
            self.name = name

    def read_temperature(self):
        """
        Reads the current temperature.

        Returns
        -------
        float
            Temperature in °C.
        """
        return self._read_data()[1] * 175.0 / 65535.0 - 45.0

    def read_humidity(self):
        """
        Reads the current relative humidity.

        Returns
        -------
        float
            Relative humidity in %.
        """
        return self._read_data()[0] / 655.35

    def read_dewpoint(self):
        """
        Reads the temperature and humidity and estimates the current dew point.

        Returns
        -------
        float
            Dew point in °C.
        """
        RH, T = np.array(self._read_data()) * np.array([100.0, 175.0]) / 65535.0 + np.array([0, -45.0])
        sdd = 6.1078 * np.exp(17.08085 * T / (234.175 + T))
        if T < 0:
            sdd = sdd * np.exp(0.00972 * T)

        dd = np.abs(RH * sdd / 100.0)
        fval = np.log(np.abs(dd / 6.1078))
        return 234.175 * fval / (17.08085 - fval)
