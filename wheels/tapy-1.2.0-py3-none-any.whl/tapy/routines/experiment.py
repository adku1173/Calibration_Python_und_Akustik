"""Contains classes to conduct experiments based on a :class:`tapy.routines.measurements.Measurement` class."""

from traits.api import List, Trait

from tapy.core.base import BasicObject
from tapy.routines.measurements import Measurement
from tapy.routines.tasks import Task


class Experiment(BasicObject):
    """The Experiment class represents a series of measurements, which are defined as tasks.

    Parameters
    ----------
    measurement : :class:`tapy.routines.measurements.Measurement`
        An instance of a :class:`tapy.routines.measurements.Measurement` derived class.
    tasks : list
        A list of :class:`tapy.routines.measurements.Task` tasks that carry the measurement data.

    Attributes
    ----------
    measurement : :class:`tapy.routines.measurements.Measurement`
        An instance of a :class:`tapy.routines.measurements.Measurement` derived class.
    tasks : list
        A list of :class:`tapy.routines.measurements.Task` tasks that carry the measurement data.
    """

    measurement = Trait(Measurement)
    tasks = List(trait=Task)

    def __init__(self, measurement, tasks, name=None):
        super().__init__(name)
        self.measurement = measurement
        self.tasks = list(tasks)[::-1]

    def conduct(self):
        """Executes the Measurement instance giving a list of Task instances."""
        with self.logger.info('Conducting experiment ...'):
            i = 0
            n = len(self.tasks)
            while self.tasks:
                i += 1
                with self.logger.info(f'Next pending task ({i}/{n}):'):
                    task = self.tasks.pop()
                    if task.dict.get('complete'):
                        self.logger.info2('Task already completed!')
                        continue
                    try:
                        self.measurement.execute(task)
                    except Exception as ex:
                        self.logger.error(f'Task failed with exception: {ex}')
            self.logger.info('No more pending tasks!')
        self.logger.info('Done.')
