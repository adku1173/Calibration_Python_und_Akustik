"""Contains classes to perform measurements based on individual tasks."""

from time import perf_counter, sleep

import numpy as np
import scipy.linalg as spla
import scipy.signal as ss
from pyfar import dsp
from pyfar.classes.audio import Signal
from pyfar.signals import exponential_sweep_time, linear_sweep_time
from traits.api import Bool, Dict, Float, Instance, Int, List, Trait, Union

from tapy.core.base import BasicObject
from tapy.core.config import config
from tapy.devices.actuators import AudioOutput
from tapy.devices.sensors import AudioInput
from tapy.routines.tasks import Task


class Measurement(BasicObject):
    """A base class for implementing a measurement.

    A measurement is composed of a preparation step, a measurement step, a
    write step, and a cleanup step. Each of these steps is implemented as a
    callable.

    Parameters
    ----------
    measure : callable
        The callable to execute the measurement step.
    prepare : callable, optional
        The callable to execute the preparation step.
    cleanup : callable, optional
        The callable to execute the cleanup step.
    write : callable, optional
        The callable to execute the write step.
    name : str, optional
        The name of the measurement.

    Attributes
    ----------
    name : str
        The name of the measurement.
    """

    def __init__(self, measure=None, prepare=None, cleanup=None, write=None, name=None):
        super().__init__(name)
        self._measure = measure
        self._prepare = prepare
        self._cleanup = cleanup
        self._write = write

    def prepare(self, task):
        """Prepare the measurement.

        Parameters
        ----------
        task : Task
            The :class:`tapy.routines.measurements.Task` object.
        """
        assert isinstance(task, Task)
        if self._prepare is not None:
            with self.logger.info('Preparing ...'):
                self._prepare(task)

    def measure(self, task):
        """Performs the measurement.

        Parameters
        ----------
        task : Task
            The :class:`tapy.routines.measurements.Task` object.
        """
        assert isinstance(task, Task)
        if self._measure is not None:
            with self.logger.info('Measuring ...'):
                self._measure(task)

    def cleanup(self, task):
        """Cleanup the measurement.

        Parameters
        ----------
        task : Task
            The :class:`tapy.routines.measurements.Task` object.
        """
        assert isinstance(task, Task)
        if self._cleanup is not None:
            with self.logger.info('Cleaning up ...'):
                self._cleanup(task)

    def write(self, task):
        """Write step after the measurement.

        Parameters
        ----------
        task : Task
            The :class:`tapy.routines.measurements.Task` object.
        """
        assert isinstance(task, Task)
        if self._write is not None:
            with self.logger.info('Writing ...'):
                self._write(task)

    def execute(self, task):
        """Executes all steps of the measurement.

        Parameters
        ----------
        task : Task
            The :class:`tapy.routines.measurements.Task` object.
        """
        assert isinstance(task, Task)
        self.prepare(task)
        self.measure(task)
        self.write(task)
        self.cleanup(task)


class SweepMeasurement(Measurement):
    """Measurement class for performing a sweep measurement with the given input and output devices.

    Parameters
    ----------
    input : AudioInput
        A subclass instance of :class:`tapy.devices.AudioInput` device
        for recording the sweep response
    output : AudioOutput
        A subclass instance of :class:`tapy.devices.AudioOutput` device
        for playing the sweep signal
    numsamples : int
        The number of samples to record. If not specified, the number of
        samples is equal to the length of the sweep signal. Only relevant
        if the input device is a :class:`tapy.devices.SinusDevice`.
    sweep_method : str
        The method to generate the sweep signal. Either
        ``'exponential_sweep'`` or ``'linear_sweep'``.
    sweep_args : dict
        The arguments to pass to the sweep method.
    input_channels : list of SinusAnalogChannel, optional
        The input channels to record. If not specified, the input channels
        of the input device are used. Only relevant if the input device is
        a :class:`tapy.devices.SinusDevice`.
    output_channels : list of SinusAnalogChannel, optional
        The output channels to play the sweep signal. If not specified, the
        output channels of the output device are used. Only relevant if the
        output device is a :class:`tapy.devices.SinusDevice`.
    gain : float
        The gain of the output sweep signal.

    Attributes
    ----------
    sweep : Signal
        The sweep signal that is played by the output device.
    """

    if config.HAVE_SINUS:
        from tapy.devices.sinus import SinusDevice
        from tapy.drivers.sinus import SinusAnalogChannel

        input = Union(Instance(AudioInput), Instance(SinusDevice))
        output = Union(Instance(AudioOutput), Instance(SinusDevice))
        input_channels = Union(None, List(Int), List(Instance(SinusAnalogChannel)))
        output_channels = Union(None, List(Int), List(Instance(SinusAnalogChannel)))
    else:
        input = Instance(AudioInput)
        output = Instance(AudioOutput)
    numsamples = Int
    sweep_method = Trait(
        'exponential_sweep',
        {'exponential_sweep': exponential_sweep_time, 'linear_sweep': linear_sweep_time},
        desc='sweep type',
    )
    sweep_args = Dict
    sweep = Instance(Signal)
    gain = Float(1, desc='gain of the output signal')

    def __init__(
        self,
        input,
        output,
        numsamples=None,
        sweep_method='exponential_sweep',
        sweep_args=None,
        input_channels=None,
        output_channels=None,
        gain=1,
        **kwargs,
    ):
        self.input = input
        self.output = output
        self.gain = gain
        if numsamples is None:
            numsamples = sweep_args['n_samples']  # same as sweep length
        elif sweep_args.get('n_samples') is None:
            sweep_args['n_samples'] = numsamples  # sweep length same as recording length if not specified
        self.numsamples = numsamples
        self.sweep_method = sweep_method
        self.sweep_args = sweep_args
        if config.HAVE_SINUS:
            from tapy.devices.sinus import SinusDevice

            if isinstance(self.input, SinusDevice):
                if input_channels is None:
                    input_channels = self.input.analog_inputs
                elif isinstance(input_channels[0], int):
                    input_channels = [self.input.analog_inputs[i - 1] for i in input_channels]
            if isinstance(self.output, SinusDevice):
                if output_channels is None:
                    output_channels = self.output.analog_outputs
                elif isinstance(output_channels[0], int):
                    output_channels = [self.output.analog_outputs[i - 1] for i in output_channels]
        self.input_channels = input_channels
        self.output_channels = output_channels
        if 'sampling_rate' not in self.sweep_args:
            self.sweep_args['sampling_rate'] = self.output.fs
        self.sweep = self.sweep_method_(**self.sweep_args)
        if kwargs.get('measure') is None:
            kwargs['measure'] = self._default_measure
        super().__init__(**kwargs)

    def _measure_sinus_device(self, signal):
        from tapy.drivers.sinus import SinusStreamContext

        with SinusStreamContext(
            channels=self.input_channels + self.output_channels, sync_start=True, num_threads=2
        ) as stream:
            with self.input.record(numsamples=self.numsamples, channels=self.input_channels, context=stream):
                with self.output.play(signal, channels=self.output_channels, context=stream):
                    pass

    def _measure_audio_device(self, signal):
        with self.input.record():
            with self.output.play(signal):
                pass

    def _single_measure(self):
        self.logger.info('Measuring sweep ...')
        signal = self.sweep.time[0]
        signal /= np.max(np.abs(signal))
        signal *= self.gain
        if config.HAVE_SINUS:
            from tapy.devices.sinus import SinusDevice

            if isinstance(self.input, SinusDevice) and isinstance(self.output, SinusDevice):
                self._measure_sinus_device(signal)
        elif isinstance(self.input, AudioInput) or isinstance(self.output, AudioOutput):
            self._measure_audio_device(signal[:, np.newaxis])
        else:
            raise ValueError('Input and output devices must be either both SinusDevices or both AudioDevices')

    def _default_measure(self, task):
        self._single_measure()
        task.dict['data'] = self.input.data


class RepeatedSweepMeasurement(SweepMeasurement):
    """Measurement class for performing a sweep measurement multiple times with the given input and output devices.

    This measurement class allows to play the sweep signal multiple times and record the responses.
    It also has the option to validate the recorded responses against each other by utilizing the
    rule of two method described in :cite:`Prawda2022`.

    Parameters
    ----------
    repetitions : int
        The number of repetitions for the repeated sweep measurement. If `validate` is True,
        and a measurement is not valid, the measurement is repeated up to `max_retries` times.
    validate : bool
        If True, the recorded responses are compared to the original sweep signal
        and only valid responses are returned.
    numsamples_noise : int, optional
        The number of noise samples to measure between the recordings of the sweep responses.
        If not specified, the measured noise length 1 second.
    align : bool, optional
        If True, the sweep responses are aligned to each other by using the cross-correlation
        of the responses. This is only relevant if ``validate`` is True.
    max_retries : int, optional
        The maximum number of retries to get a valid measurement. Defaults to 0 (no retries).
    validation_indices : list of int, optional
        The indices of the channels to validate. If not specified, all channels are validated.
    loopback_index : int, optional
        The index of the loopback signal in the sweep responses. Defaults to -1.
    mincorr : float, optional
        A minimum correlation threshold. Defaults to 0.0. If the correlation threshold determined
        by the rule of two is below this value, mincorr will be used as a lower correlation bound.


    Attributes
    ----------
    sweep : Signal
        The sweep signal that is played by the output device
    """

    repetitions = Int
    validate = Bool
    numsamples_noise = Int
    align = Bool
    max_retries = Int
    validation_indices = Union(None, List(Int))
    loopback_index = Int
    mincorr = Float
    return_invalid = Bool

    def __init__(
        self,
        repetitions,
        validate,
        numsamples_noise,
        align=True,
        max_retries=0,
        validation_indices=None,
        loopback_index=-1,
        mincorr=0.0,
        return_invalid=False,
        **kwargs,
    ):
        self.repetitions = repetitions
        self.validate = validate
        self.align = align
        self.max_retries = max_retries
        self.validation_indices = validation_indices
        if kwargs.get('measure') is None:
            kwargs['measure'] = self._measure
        super().__init__(**kwargs)
        self.numsamples_noise = numsamples_noise
        self.mincorr = mincorr
        self.return_invalid = return_invalid

    def _measure_noise(self):
        """Records the noise."""
        with self.logger.info('Recording noise ...'):
            if config.HAVE_SINUS:
                from tapy.devices.sinus import SinusDevice

                if isinstance(self.input, SinusDevice):
                    with self.input.record(numsamples=self.numsamples_noise, channels=self.input_channels):
                        pass
            elif isinstance(self.input, AudioInput):
                with self.input.record():
                    sleep(self.numsamples_noise / self.input.fs)

    def _log_invalid(self, rep, valid, rho, rho_tau, ch):
        fidx = np.argwhere(~valid[:, :rep, rep])
        if fidx.size:
            with self.logger.info2('Invalid! Ro2 fails for:'):
                for c, j in fidx:
                    if rho[c, j, rep] < rho_tau[c, j, rep]:
                        self.logger.warning(
                            f'Measurements {rep + 1}<->{j + 1} | Channel {ch[c] + 1} \
                        with: ρ = {rho[c, j, rep]:.4f} < {rho_tau[c, j, rep]:.4f}!'
                        )

    def _default_measure(self, task):
        # initialize
        data = []
        noise = []
        max_msm = self.repetitions
        if self.validate:
            max_msm += self.max_retries
            ch = range(len(self.input_channels)) if self.validation_indices is None else self.validation_indices
            valid = np.zeros((len(ch), max_msm, max_msm), dtype=bool)
            rho = np.zeros_like(valid, dtype=float)
            rho_tau = np.zeros_like(valid, dtype=float)
            data_val = []
            noise_val = []
            loopback = []

        # perform measurements
        for i in range(max_msm):
            self.logger.info(f'Measurement {i + 1}/{max_msm} ...')
            self._measure_noise()
            noise.append(self.input.data)
            self._single_measure()
            data.append(self.input.data)
            if self.validate:
                data_val.append(self._filter(data[i][ch]))
                noise_val.append(self._filter(noise[i][ch]))
                loopback.append(data[i][self.loopback_index])

                if i > 0:
                    with self.logger.info(f'Validating measurement {i + 1} ...'):
                        tic = perf_counter()
                        validate_sweeps(
                            data_val,
                            noise_val,
                            loopback,
                            valid,
                            rho,
                            rho_tau,
                            mincorr=self.mincorr,
                            align=self.align,
                        )
                        self.logger.driver(f'Validation time: {perf_counter() - tic}s')
                        self._log_invalid(i, valid, rho, rho_tau, ch)
                if i >= self.repetitions - 1:
                    valid_rep = np.all(valid, axis=0)
                    idx = return_valid_sweep_indices(valid_rep, self.repetitions)
                    if idx.size == self.repetitions:
                        self.logger.info(f'Measurement successful! (valid measurements: {idx + 1})')
                        task.dict['complete'] = True
                        break
                    elif i == max_msm - 1:
                        self.logger.error(
                            f'Maximum number of {self.max_retries} retries reached! \
                        Could not find {self.repetitions} valid measurements!'
                        )
                        task.dict['complete'] = False
                    else:
                        self.logger.info('Retrying ...')

        if not self.return_invalid and self.validate:
            task.dict['data'] = [d for j, d in enumerate(data) if j in idx]
            task.dict['noise'] = [n for j, n in enumerate(noise) if j in idx]
        else:
            task.dict['data'] = data
            task.dict['noise'] = noise
        if self.validate:
            task.dict['valid'] = valid
            task.dict['rho'] = rho
            task.dict['rho_tau'] = rho_tau

    def _filter(self, data):
        """Applies bandpass filter to desired freq range."""
        signal = Signal(data, sampling_rate=self.input.fs)
        return dsp.filter.butterworth(signal, N=3, frequency=self.sweep_args['frequency_range'], btype='bandpass').time


def validate_sweeps(sweeps, noise, loop, valid, rho, rho_tau, mincorr, align):
    """Evaluate the similarities of `sweeps[-1]` to `sweeps[:-1]` by applying the rule of two :cite:`Prawda2022`.

    The rule of two states that if the correlation coefficient between two
    signals is greater than a specific threshold (depending on the SNR), then they are similar.

    Parameters
    ----------
    sweeps : list of ndarrays
        The sweep signals recorded
    noise : list of ndarrays
        The noise recorded during the pause between the sweeps
    loop : list of ndarrays
        The loopback signals recorded
    valid : ndarray
        The validation matrix of shape (number of channels, number of repetitions, number of repetitions)
    rho : ndarray
        The measured correlation matrix of shape (same shape as valid)
    rho_tau : ndarray
        The correlation threshold matrix of shape (same shape as valid)
    mincorr : float
        The minimum correlation threshold
    align : bool
        If True, the sweeps are aligned to each other by using the cross-correlation function
        of the loopback signal.
    """
    # start validation
    col = len(sweeps) - 1
    for i in range(col):
        if align:
            y1, y2 = align_sweeps(sweeps[i], sweeps[-1], loop[i], loop[-1])
        else:
            y1 = sweeps[i]
            y2 = sweeps[-1]
        r, rt = rule_of_two(y1, y2, noise[i], noise[-1])
        rt = np.fmax(rt, mincorr)
        rho[:, i, col] = r
        rho_tau[:, i, col] = rt
        valid[:, i, col] = r > rt


def align_sweeps(y1, y2, lb1, lb2):
    """Aligns the sweeps by using the loopback signal."""
    cross_corr_func = ss.correlate(lb1, lb2, mode='same')
    shift = cross_corr_func.argmax() - lb1.shape[0] // 2  # sample shift to align the sweeps
    # align sweeps
    if shift > 0:
        y1 = y1[:, shift:]
        y2 = y2[:, :-shift]
    elif shift < 0:
        y1 = y1[:, :shift]
        y2 = y2[:, -shift:]
    return y1, y2


def pcc(y1, y2):
    """Pearson correlation coefficient.

    Same equation as in the paper:
    Prawda, J., & Schlecht, S., & Välimäki, V. (2023). Short-term Rule of Two:
    Localizing Non-Stationary Noise Events in Swept-Sine Measurements.

    Parameters
    ----------
    y1 : ndarray of shape (numchannels, numsamples)
        first measured sweep signal
    y2 : ndarray of shape (numchannels, numsamples)
        second measured sweep signal

    Returns
    -------
    ndarray of shape (numchannels,)
        Pearson correlation coefficient between y1 and y2 channelwise
    """
    return np.sum(y1 * y2, axis=1) / np.sqrt(np.sum(y1**2, axis=1) * np.sum(y2**2, axis=1))


def rule_of_two(y1, y2, n1, n2=None):
    """Rule of two method.

    Rule of two method to identify a pair of clean exponential swept sines
    in a series of repeated sweep measurements. Calculates the correlation
    and the minimum correlation threshold `rho_tau`.

    Parameters
    ----------
    y1 : ndarray
        first measured sweep signals with shape (numchannels, numsamples)
    y2 : ndarray
        second measured sweep signals with shape (numchannels, numsamples)
    n1 : ndarray
        measured background noise with shape (numchannels, numsamples)
    n2 : ndarray
        measured background noise with shape (numchannels, numsamples)

    Returns
    -------
    ndarray
        measured pearson correlation coefficient
    ndarray
        minimum correlation threshold
    """
    # pre-calculate signal energies
    e_y1 = (y1**2).sum(1)
    e_ydiff = ((y1 - y2) ** 2).sum(1)
    e_n1 = _calc_median_noise_pow(n1)
    e_y1y2 = e_ydiff
    lower_corr = _calc_lower_corr(e_y1, e_n1)
    if n2 is not None:
        e_y1y2 -= _calc_median_noise_pow(n1 - n2)  # eq. 15
        # lower_corr = np.fmax(lower_corr, _calc_lower_corr(e_y2, e_n2))
    # calc rule of two
    measured_rho = np.abs(pcc(y1, y2))
    tau = e_y1y2 / (e_y1 - 1 / 2 * e_y1y2 - e_n1)  # eq. 17
    rho_tau = lower_corr / (1 + tau / 2)  # eq. 19
    return measured_rho, rho_tau


def _calc_lower_corr(e_y, e_n):
    """Eq. 9. lower bound for the correlation coefficient.

    Prawda et al., 2022, also use eq. 11 (correlated/anti-correlated noise), which
    is less strict.
    """
    # return (e_y - e_n) / e_y # eq. 9
    return (e_y - 2 * e_n) / e_y  # eq. 11


def _calc_median_noise_pow(n, axis=1):
    """Calculates the median-based noise power according to Eq.(22) in Prawda et al., 2022.

    Parameters
    ----------
    n : numpy.array
        contains the noise measures (column-wise)

    Returns
    -------
    numpy.array
        median-based noise power
    """
    return (1.4826**2) * np.median(n**2, axis=axis) * n.shape[1]


def return_valid_sweep_indices(A, k):  # noqa: N803
    Q, R, p = spla.qr(A, pivoting=True)
    sub = np.sort(p[:k])
    A_sub = A[sub][:, sub]
    if np.sum(A_sub) != k * (k - 1) / 2:
        sub = np.array([])
    return sub
