"""Contains task classes used as data carrier during measurements."""

import gc
import json
from abc import abstractmethod
from contextlib import AbstractContextManager, nullcontext
from pathlib import Path

import numpy as np
import pymongo as pm
from traits.api import Bool, Dict, Either, Float, Instance, List, Property, Str, Tuple

from tapy.core.base import BasicObject
from tapy.core.config import config
from tapy.core.connect import MongoDBConnection


class Task(BasicObject):
    """Abstract container for holding data.

    A `Task` instance is usually given to an instance of :class:`Measurement` or
    :class:`Experiment` where it is filled with data.

    Parameters
    ----------
    dict : dict
        Dictionary holding data for the :class:`Task`.
    name : str, optional
        Name of the :class:`Task`. Default is the class name.

    Attributes
    ----------
    dict : dict
        Dictionary holding data for the :class:`Task`.
    name : str
        Name of the :class:`Task`.
    """

    dict = Instance(dict)

    def __init__(self, dict=None, name=None):
        super().__init__(name)
        self.dict = {} if dict is None else dict

    def cleanup(self):
        """Deletes the data in :attr:`dict` manually and starts garbage collection."""
        del self.dict
        gc.collect()

    @abstractmethod
    def execute(self):
        """Executes a task specific routine (e.g. file saving, database operation)."""


class MultiTask(Task):
    """Container for holding multiple :class:`Task` instances.

    The :class:`MultiTask` is intended to allow multiple different tasks to be executed.
    This for example enables to write to a database and to a file on disk simultaniously.
    For example, the following code will write the dictionary `d` to a MongoDB collection
    and to a HDF5 file, whereby each individual task excludes a specific key from the dictionary:

    >>> d = dict({'a': 1, 'b': 2})
    >>>
    >>> t1 = MongoTask(dict={}, collection=collection, exclude_keys=['b'])
    >>> t2 = HDF5Task(dict={}, filepath='.', filename='test.h5', exclude_keys=['a'])
    >>> MultiTask(tasks=(t1, t2), dict=d).execute()

    Parameters
    ----------
    tasks : tuple(:class:`Task`)
        Tuple of :class:`Task` instances.
    dict : dict
        Dictionary holding data (linked to the individual tasks in :attr:`tasks`).
    name : str
        Name of the :class:`MultiTask`.

    Attributes
    ----------
    tasks : tuple(:class:`Task`)
        Tuple of :class:`Task` instances.
    dict : dict
        Dictionary holding data (linked to the individual tasks in :attr:`tasks`).
    name : str
        Name of the :class:`MultiTask`.
    """

    tasks = Tuple()

    def __init__(self, tasks, dict, name=None):
        super().__init__(dict=dict, name=name)
        self.tasks = tasks
        for task in self.tasks:
            task.dict = dict

    def execute(self):
        """Executes all tasks in :attr:`tasks`."""
        for task in self.tasks:
            task.execute()


class JSONTask(Task):
    """Task for saving data to a JSON file.

    Parameters
    ----------
    filepath : str
        The filepath to save the JSON file to.
    filename : str, optional
        The name of the JSON file. If not provided, the file will be named after the task's unique
        identifier.
    exclude_keys : list, optional
        List of keys to exclude when saving data to the JSON file. Defaults to an empty list.
    ssh_connection : :class:`SSHConnection`, optional
        In case the write directory is a locally mounted remote directory, the necessary
        ssh connection can be defined here.
    **kwargs
        Additional keyword arguments passed to the parent Task class.

    Attributes
    ----------
    directory : pathlib.Path
        The directory to save the JSON file to.
    filename : str
        The name of the JSON file.
    exclude_keys : list
        List of keys to exclude when saving data to the JSON file.
    """

    filepath = Instance(Path)
    exclude_keys = List
    _ssh = Instance(AbstractContextManager)
    _suffix = Str('.json')

    def __init__(self, directory=None, filename=None, exclude_keys=None, ssh_connection=None, **kwargs):
        super().__init__(**kwargs)
        self.exclude_keys = [] if exclude_keys is None else exclude_keys
        directory = Path() if directory is None else Path(directory)
        filename = self.uid if filename is None else filename
        self.filepath = directory / (Path(filename).stem + self._suffix)
        self._ssh = nullcontext() if ssh_connection is None else ssh_connection

    def _save(self):
        with open(self.filepath.resolve(), 'w') as file:
            d = dict()
            for key, value in self.dict.items():
                if key not in self.exclude_keys:
                    d[key] = value.tolist() if isinstance(value, np.ndarray) else value
            json.dump(d, file)

    def execute(self):
        """Save the data in :attr:`dict` to a JSON file."""
        with self._ssh:
            self._save()
        self.logger.info(f'Saved task {self.uid} to {self.filepath.name}.')


class MongoTask(Task):
    """Task for inserting or updating documents in a MongoDB collection.

    A Task to store data from :attr:`dict` in a MongoDB collection.
    A Mongo database (MongoDB) is a NoSQL style database. A collection of the
    database contains key-value pairs similar to the task dictionary.
    The class relies on pymongo. The collecition must be passed to this class
    via the :attr:`collection` attribute. For example

    >>> from tapy.core.connect import MongoDBConnection
    >>> from tapy.routines.tasks import MongoTask

    >>> connection = MongoDBConnection(ip_address_or_host='localhost', port=27017)
    >>> db = 'test'  # the database name
    >>> collection = 'subtest'  # the collection name
    >>> task = MongoTask(
    ...     connection=connection, db=db, collection=collection, dict={'a': 1, 'b': 2}
    ... )

    To store the data in the collection, the :meth:`execute` method must be called.

    >>> task.execute()

    Data can also be retrieved from a collection and then updated if the object key
    is known. For example:

    >>>    task.id = '100cc61e-58f6-499e-8bfe-bd7f356752b4_1'
    >>>    task.retrieve() # retrieve the data from the collection
    >>>    print(task2.dict) # print the data
    >>>    task2.dict["b"] = 3 # update the data
    >>>    task2.execute()  # store the updated data in the collection


    Parameters
    ----------
    connection : :class:`MongoDBConnection`
        The MongoDB connection to use.
    db : str
        The MongoDB database name to insert or update documents in.
    collection : str
        The MongoDB collection name to insert or update documents in.
    allow_duplicates : bool, optional
        Whether to allow inserting duplicate documents into the collection.
        Defaults to False.
    duplicate_query : list, optional
        List of keys to use for querying the collection. Defaults to an empty list.
        Necessary if the collection contains duplicate documents.
    exclude_keys : list, optional
        List of keys to exclude when inserting or updating documents. Defaults
        to an empty list.
    id : str, optional
        The id of the document in the collection. If None, the id is set to the :attr:`uid` of
        the task
    **kwargs
        Additional keyword arguments passed to the parent Task class.


    Attributes
    ----------
    collection : pymongo.collection.Collection
        The MongoDB collection to insert or update documents in.
    allow_duplicates : bool
        Whether to allow inserting duplicate documents into the collection.
    duplicate_query : dict
        Dict to use for querying the collection for duplicate documents.
    exclude_keys : list
        List of keys to exclude when inserting or updating documents.
    """

    connection = Instance(MongoDBConnection)
    db = Str
    collection = Property
    duplicate_query = Property
    allow_duplicates = Bool
    exclude_keys = Either(None, List)
    id = Str
    timeout = Float
    _collection = Str
    _duplicate_query = Either(None, Dict)

    def __init__(
        self,
        connection,
        db,
        collection,
        allow_duplicates=False,
        duplicate_query=None,
        exclude_keys=None,
        timeout=10,
        id=None,
        **kwargs,
    ):
        self.connection = connection
        self.db = db
        self.collection = collection
        self.allow_duplicates = allow_duplicates
        self.timeout = timeout
        if exclude_keys is None:
            exclude_keys = []
        self.exclude_keys = exclude_keys
        self.duplicate_query = duplicate_query
        super().__init__(**kwargs)
        if id is None:
            self.id = self.uid
        else:
            self.id = id

    @classmethod
    def from_collection(cls, *args, **kwargs):
        """Instantiate a MongoTask object and try to match it to some document in the database.

        If a matching document is foundset its `id` to a matching document in the database.
        """
        mtask = cls(*args, **kwargs)
        if mtask.duplicate_query is not None:
            document = mtask.duplicate_query
        else:
            document = mtask.create_valid_document(mtask.dict)
        with mtask.connection:
            n_duplicates = mtask.count_duplicates(document)
            if n_duplicates != 0:
                if n_duplicates > 1:
                    mtask.logger.warning(f'Found {n_duplicates} duplicates for document {document}')
                mtask.id = str(mtask.collection.find_one(document)['_id'])
                mtask.retrieve()
        return mtask

    def _set_collection(self, collection):
        self._collection = collection

    def _get_collection(self):
        with self.connection:
            db = self.connection._client[self.db]
            return db[self._collection]

    def _set_duplicate_query(self, duplicate_query):
        self._duplicate_query = None if duplicate_query is None else self.create_valid_document(duplicate_query)

    def _get_duplicate_query(self):
        return self._duplicate_query

    def count_duplicates(self, query):
        """Counts the duplicate documents in the collection."""
        if self.duplicate_query is not None:
            query = self.duplicate_query
        with self.connection:
            return self.collection.count_documents(query)

    def create_valid_document(self, doc):
        """Create a valid document from dict by excluding numpy arrays and self.exclude_keys."""
        d = dict()
        for key, value in doc.items():
            if key in self.exclude_keys:
                continue
            if isinstance(value, np.ndarray):
                d[key] = value.tolist()
            elif np.isscalar(value):
                try:
                    d[key] = value.item()
                except AttributeError:
                    d[key] = value
            else:
                d[key] = value
        return d

    def insert(self):
        """Insert a new document into the collection."""
        document = self.create_valid_document(self.dict)
        if not self.allow_duplicates:
            assert self.count_duplicates(document) == 0
        with self.connection:
            self.collection.insert_one(document | {'_id': self.id})
        self.logger.info(f'inserted document with id {self.id}')

    def update(self):
        """Update an existing document in the collection."""
        with self.connection:
            self.collection.update_one({'_id': self.id}, {'$set': self.create_valid_document(self.dict)})
        self.logger.info(f'updated document with id {self.id}')

    def retrieve(self):
        """Retrieve a document from the collection and write its data to :attr:`dict`."""
        with self.connection:
            self.dict.update(self.collection.find_one({'_id': self.id}))

    def execute(self):
        """Insert or update a document in the collection based on whether it already exists."""
        with self.connection:
            with pm.timeout(self.timeout):
                if self.collection.count_documents({'_id': self.id}) == 0:
                    self.insert()
                else:
                    self.update()


if config.HAVE_H5PY:
    import h5py

    class HDF5Task(JSONTask):
        """Task for saving data to a HDF5 file.

        Parameters
        ----------
        directory : pathlib.Path
            The directory to save the HDF5 file to.
        filename : str, optional
            The name of the HDF5 file. If not provided, the file will be named
            after the task's unique identifier.
        exclude_keys : list, optional
            List of keys to exclude when saving data to the HDF5 file. Defaults
            to an empty list.
        **kwargs
            Additional keyword arguments passed to the parent Task class.


        Attributes
        ----------
        directory : str
            The directory to save the HDF5 file to.
        filepath : str
            The name of the HDF5 file.
        exclude_keys : list
            List of keys to exclude when saving data to the HDF5 file.
        """

        _suffix = Str('.h5')

        def _save(self):
            with h5py.File(self.filepath.resolve(), 'w') as file:
                for key, value in self.dict.items():
                    if key not in self.exclude_keys:
                        file.create_dataset(key, data=value)
