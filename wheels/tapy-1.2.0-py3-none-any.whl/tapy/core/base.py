"""Provides a base class from which most classes in TAPy inherit.

The purpose of the base class is to provide some common functionality for
all objects in TAPy. The most notable features provided by :class:`BasicObject`
are the following:

    1. Each *class* deriving from :class:`BasicObject` comes with its own
       :mod:`~tapy.core.logger` instance accessible through its `logger`
       attribute. The logger prefix is automatically set to the class name.
    2. Logging can be disabled and re-enabled for each *instance* using the
       :meth:`BasicObject.disable_logging` and :meth:`BasicObject.enable_logging`
       methods.
    3. :meth:`BasicObject.uid` provides a unique id for each instance. While
       `id(obj)` is only guaranteed to be unique among all living Python objects,
       :meth:`BasicObject.uid` will be (almost) unique among all TAPy objects
       that have ever existed, including previous runs of the application. This
       is achieved by building the id from a uuid4 which is newly created for
       each TAPy run and a counter which is increased for any object that requests
       an uid.
    4. If not set by the user to another value, :attr:`BasicObject.name` is
       set to the name of the object's class.
"""

import uuid

from traits.api import HasPrivateTraits, Property, ReadOnly, Str

from tapy.core import logger


class UID:
    """Provides unique, quickly computed ids by combining a session UUID4 with a counter.

    This class is part of the `pyMOR project <https://www.pymor.org>`_.
    Copyright pyMOR developers and contributors. All rights reserved.
    License: `BSD 2-Clause License <https://opensource.org/licenses/BSD-2-Clause>`_
    """

    __slots__ = ['uid']

    prefix = f'{uuid.uuid4()}_'
    counter = [0]

    def __init__(self):
        self.uid = self.prefix + str(self.counter[0])
        self.counter[0] += 1

    def __getstate__(self):
        """Method called when the object is pickled.

        Returns
        -------
            int: 1
        """
        return 1

    def __setstate__(self, v):
        """Method called when the object is unpickled.

        Args:
            v: any object (unused)
        """
        self.uid = self.prefix + str(self.counter[0])
        self.counter[0] += 1


class BasicObject(HasPrivateTraits):
    """Base class for all classes in TAPy.

    This class is part of the `pyMOR project <https://www.pymor.org>`_.
    Copyright pyMOR developers and contributors. All rights reserved.
    License: `BSD 2-Clause License <https://opensource.org/licenses/BSD-2-Clause>`_

    Parameters
    ----------
    name : str, optional
        The name of the object. This will be used for logging purposes.

    Attributes
    ----------
    logger
        A per-class instance of :class:`logging.Logger` with the class name as prefix.
    logging_disabled
        `True` if logging has been disabled.
    uid
        A unique id for each TAPy object ever created. The uid is obtained by using :class:`UID`.
    """

    def __init__(self, name=None):
        HasPrivateTraits.__init__(self)
        self.name = name if name else type(self).__name__
        self._logger = logger.getLogger(f'{self.__module__.replace("__main__", "tapy")}.{self.name}')
        self.uid = UID().uid

    logger = Property
    name = Str
    uid = ReadOnly

    @property
    def logging_disabled(self):
        return self._logger is logger.dummy_logger

    def _get_logger(self):
        return self._logger

    def disable_logging(self, doit=True):
        """Disable logging output for this instance."""
        if doit:
            self._logger = logger.dummy_logger
        else:
            self._logger = logger.getLogger(f'{self.__module__.replace("__main__", "tapy")}.{self.name}')

    def enable_logging(self, doit=True):
        """Enable logging output for this instance."""
        self.disable_logging(not doit)

    def __iter__(self):
        """Enables casting a BasicObject as dict, i.e. ``dict(self)``."""
        for d in [d for d in dir(self) if not d.startswith('_') and 'trait' not in d]:
            try:
                if d not in ['get', 'set', 'observe', 'wrappers']:
                    yield d, getattr(self, d)
            except AttributeError:
                pass
