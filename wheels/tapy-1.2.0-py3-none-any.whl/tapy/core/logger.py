# This file is part of the pyMOR project (https://www.pymor.org).
# Copyright pyMOR developers and contributors. All rights reserved.
# License: BSD 2-Clause License (https://opensource.org/licenses/BSD-2-Clause)

"""Contains TAPy's logging facilities (taken from pyMOR).

TAPy's logging facilities are based on the :mod:`logging` module of the
Python standard library. To obtain a new logger object use :func:`getLogger`.
Logging can be configured via :func:`configure_logger`.
"""

import logging
import time
from functools import lru_cache
from types import MethodType

from rich.console import Console
from rich.highlighter import NullHighlighter
from rich.logging import RichHandler
from rich.progress import Progress
from rich.theme import Theme

theme = Theme(
    {
        'logging.level.debug': 'bright_blue',
        'logging.level.driver': 'cyan',
        'logging.level.info': 'white',
        'logging.level.info2': 'yellow',
        'logging.level.info3': 'red',
        'logging.level.warning': 'yellow reverse',
        'logging.level.error': 'red reverse',
        'logging.level.critical': 'bright_magenta blink',
    }
)
CONSOLE = Console(markup=True, theme=theme)

DEBUG = logging.DEBUG
DRIVER = DEBUG + 5
INFO = logging.INFO
INFO2 = logging.INFO + 1
INFO3 = logging.INFO + 2
logging.addLevelName(DRIVER, 'DRIVER')
logging.addLevelName(INFO2, 'INFO2')
logging.addLevelName(INFO3, 'INFO3')


OUTPUTS = None
MAX_HIERARCHY_LEVEL = 1
INDENT_BLOCKS = True
INDENT = 0
LAST_TIMESTAMP_LENGTH = 0

start_time = time.perf_counter()


class ColoredFormatter(logging.Formatter):
    """A logging.Formatter that colors loglevel keyword output.

    Coloring can be disabled by setting the `TAPY_COLORS_DISABLE` environment variable to `1`.
    """

    def _format_common(self, record):
        global LAST_TIMESTAMP_LENGTH

        msg = super().format(record)  # call base class to support exception formatting

        # format time
        elapsed = int(time.perf_counter() - start_time)
        days, remainder = divmod(elapsed, 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes, seconds = divmod(remainder, 60)
        timestamp = (
            f'{days}d {hours:02}:{minutes:02}:{seconds:02}'
            if days
            else f'{hours:02}:{minutes:02}:{seconds:02}'
            if hours
            else f'{minutes:02}:{seconds:02}'
        )
        if LAST_TIMESTAMP_LENGTH == 0:
            LAST_TIMESTAMP_LENGTH = len(timestamp)

        # handle special cases
        if not record.msg:
            return ' ' * (LAST_TIMESTAMP_LENGTH + 1) + '|   ' * INDENT

        # handle length change of timestamp
        if len(timestamp) > LAST_TIMESTAMP_LENGTH:
            timestep_length = len(timestamp)
            if INDENT > 0:
                for i in reversed(range(LAST_TIMESTAMP_LENGTH, timestep_length)):
                    timestamp = ' ' * (i + 2) + r'\   ' * INDENT + '\n' + timestamp
            LAST_TIMESTAMP_LENGTH = timestep_length

        indent = '|   ' * INDENT

        tokens = record.name.split('.')
        if len(tokens) > MAX_HIERARCHY_LEVEL - 1:
            path = '.'.join(tokens[1:MAX_HIERARCHY_LEVEL] + [tokens[-1]])
        else:
            path = '.'.join(tokens[1:MAX_HIERARCHY_LEVEL])

        return path, msg, timestamp, indent

    def format(self, record):
        try:
            ret = self._format_common(record)
            path, msg, timestamp, indent = ret
        except ValueError:
            return ret

        return f'{timestamp}\t{indent}{path}: {msg}'


def getLogger(module, level=None):
    """Get the logger of the respective module for TAPy's logging facility.

    In addition to the logging methods inherited from :class:`~logging.Logger`
    all returned loggers get a info2, info3, driver method for the
    respective new levels. Plus all warnings methods get a `XXX_once` method
    that caches the msg and only emits the log entry the first time (per logger
    instance, not globally).

    Parameters
    ----------
    module
        Name of the module.
    level
        If set, `logger.setLevel(level)` is called (see
        :meth:`~logging.Logger.setLevel`).
    filename
        If not empty, path of an existing file where everything logged will be
        written to.
    """
    module = 'tapy' if module == '__main__' else module

    logger = logging.getLogger(module)
    logger.debug = MethodType(_debug, logger)
    logger.driver = MethodType(_driver, logger)
    logger.info = MethodType(_info, logger)
    logger.info2 = MethodType(_info2, logger)
    logger.info3 = MethodType(_info3, logger)
    for level_function in ('info', 'error', 'fatal', 'debug', 'driver', 'info2', 'info3', 'warning'):
        # add a method that is wrapped in a cache, so calls with same args are not executed again
        setattr(logger, f'{level_function}_once', lru_cache(None)(getattr(logger, level_function)))

    global OUTPUTS
    handlers = []
    for out, lvl in OUTPUTS.items():
        handler = (
            RichHandler(
                markup=True,
                show_time=False,
                show_path=False,
                show_level=True,
                console=CONSOLE,
                highlighter=NullHighlighter(),
            )
            if out == 'STDOUT'
            else logging.FileHandler(out)
        )
        handler.setFormatter(ColoredFormatter())
        handler.setLevel(lvl)
        handlers.append(handler)
    logger.handlers = handlers
    logger.propagate = False
    if level:
        logger.setLevel(level)
    return logger


def configure_logger(levels=None, outputs=None, max_hierarchy_level=1, indent_blocks=True):
    """Configure the behaviour of TAPy's logging facility.

    Parameters
    ----------
    levels
        Dict of log levels. Keys are names of loggers (see :func:`logging.getLogger`),
        values are the log levels to set for the loggers of the given names
        (see :meth:`~logging.Logger.setLevel`).
    outputs
        Dict of log outputs. Keys are either `STDOUT` or filenames,
        values are the minimum log levels to set for the loggers of the given output.
        (see :meth:`~logging.Logger.setLevel`).
    max_hierarchy_level
        The number of components of the loggers name which are printed.
        (The first component is always stripped, the last component always
        preserved.)
    indent_blocks
        If `True`, indent log messages inside a code block started with
        `with logger.info(...):`.
    """
    global MAX_HIERARCHY_LEVEL, INDENT_BLOCKS, OUTPUTS
    MAX_HIERARCHY_LEVEL = max_hierarchy_level
    INDENT_BLOCKS = indent_blocks
    OUTPUTS = outputs if outputs else {'STDOUT': 'DEBUG'}

    levels = levels or {'tapy': 'INFO'}

    for k, v in levels.items():
        getLogger(k, level=v)


class LogIndenter:
    def __init__(self, logger, doit):
        self.logger = logger
        self.doit = doit

    def __enter__(self):
        global INDENT
        if self.doit:
            INDENT += 1

    def __exit__(self, exc_type, exc_val, exc_tb):
        global INDENT
        if self.doit:
            INDENT -= 1


def _debug(self, msg, *args, **kwargs):
    global INDENT_BLOCKS
    self.log(DEBUG, msg, *args, **kwargs)
    return LogIndenter(self, self.isEnabledFor(DEBUG) and INDENT_BLOCKS)


def _driver(self, msg, *args, **kwargs):
    global INDENT_BLOCKS
    self.log(DRIVER, msg, *args, **kwargs)
    return LogIndenter(self, self.isEnabledFor(DRIVER) and INDENT_BLOCKS)


def _info(self, msg, *args, **kwargs):
    global INDENT_BLOCKS
    self.log(INFO, msg, *args, **kwargs)
    return LogIndenter(self, self.isEnabledFor(INFO) and INDENT_BLOCKS)


def _info2(self, msg, *args, **kwargs):
    global INDENT_BLOCKS
    self.log(INFO2, msg, *args, **kwargs)
    return LogIndenter(self, self.isEnabledFor(INFO2) and INDENT_BLOCKS)


def _info3(self, msg, *args, **kwargs):
    global INDENT_BLOCKS
    self.log(INFO3, msg, *args, **kwargs)
    return LogIndenter(self, self.isEnabledFor(INFO3) and INDENT_BLOCKS)


class DummyLogger:
    __slots__ = []

    def nop(self, *args, **kwargs):
        return None

    propagate = False
    warn = nop
    warning = nop
    error = nop
    critical = nop
    log = nop
    exception = nop

    def isEnabledFor(self, lvl):
        return False

    def getEffectiveLevel(self):
        return None

    def getChild(self):
        return self

    def debug(self, msg, *args, **kwargs):
        return LogIndenter(self, False)

    def driver(self, msg, *args, **kwargs):
        return LogIndenter(self, False)

    def info(self, msg, *args, **kwargs):
        return LogIndenter(self, False)

    def info2(self, msg, *args, **kwargs):
        return LogIndenter(self, False)

    def info3(self, msg, *args, **kwargs):
        return LogIndenter(self, False)


dummy_logger = DummyLogger()

PROGRESS_BAR = Progress(expand=True, transient=True, console=CONSOLE)
