"""Contains FastAPI server implementation for TAPy objects."""

import asyncio
import inspect
from contextlib import asynccontextmanager
from json import JSONEncoder
from pathlib import Path
from queue import Empty, Queue

import uvicorn
from fastapi import APIRouter, FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel
from rich.logging import RichHandler
from traits.api import Dict, Instance, Int

from tapy.core.base import BasicObject
from tapy.core.logger import ColoredFormatter

POLLING_INTERVAL = 0.01


formatter = ColoredFormatter()
formatter.use_color = False


async def stream_logs(logs):
    """Stream logs from a queue."""
    while True:
        try:
            record = logs.get_nowait()
        except Empty:
            pass
        else:
            yield formatter.format(record) + '\n'
        finally:
            await asyncio.sleep(POLLING_INTERVAL)


class LogEncoder(JSONEncoder):
    """Encodes log record to JSON."""

    def default(self, obj):
        try:
            return obj.__dict__['records']
        except KeyError:
            return obj.__dict__


class QueueHandler(RichHandler):
    def __init__(self, queues):
        super().__init__()
        self.queues = queues

    def emit(self, record):
        for q in self.queues:
            q.put_nowait(record)


class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, client_id: str):
        await websocket.accept()
        exist: WebSocket = self.active_connections.get(client_id)
        if exist:
            await exist.close()  # you want to disconnect connected client.
            self.active_connections[client_id] = websocket
            # await websocket.close()  # reject new user with the same ID already exist
        else:
            self.active_connections[client_id] = websocket

    def disconnect(self, websocket: WebSocket, client_id: str):
        self.active_connections.pop(client_id)

    async def broadcast(self, message: str):
        for connection in self.active_connections.values():
            await connection.send_text(message)


# create SubAPIs for TAPy-objects
def endpoints_from_object(obj):
    endpoints = []
    for k, attr in dict(obj).items():
        if k == 'logger':
            continue
        if k in ('uid',):
            type = 'readonly'
        elif inspect.ismethod(attr):
            if inspect.iscoroutinefunction(attr):
                type = 'async-post'
            else:
                type = 'sync-post'
        else:
            type = 'property'
        endpoints.append({'path': f'/{obj.name}/{k}', 'name': k, 'type': type})
    return endpoints


class _Item(BaseModel):
    args: tuple
    kwargs: dict


class SubAPI:
    def __init__(self, obj, id, all_logs):
        self.router = APIRouter(prefix=id)
        self.logs = Queue()
        self.all_logs = all_logs
        self.wsq = Queue()

        manager = ConnectionManager()

        obj.logger.addHandler(QueueHandler([self.logs, self.wsq, all_logs]))
        obj.logger.setLevel('DEBUG')

        self.obj = obj
        for e in endpoints_from_object(obj):
            self.create_endpoint(e['name'], e['type'])

        @self.router.get('/endpoints')
        def get_all_endpoints():
            return endpoints_from_object(self.obj)

        @self.router.get('/logger')
        async def logger():
            return StreamingResponse(stream_logs(self.logs), media_type='text/event-stream')

        @self.router.websocket('/ws/{client_id}')
        async def websocket_endpoint(ws: WebSocket, client_id: str):
            await manager.connect(ws, client_id)
            while True:
                try:
                    record = self.wsq.get_nowait()
                except Empty:
                    await asyncio.sleep(POLLING_INTERVAL)
                else:
                    try:
                        await manager.broadcast(LogEncoder().encode(record))
                    except WebSocketDisconnect:
                        await manager.disconnect(ws, client_id)
                        break

    def create_endpoint(self, name, type):
        attr = getattr(self.obj, name)
        if type == 'async-post':

            @self.router.post(f'/{name}')
            async def asyncpost(item: _Item):
                await attr(*item.args, **item.kwargs)
        elif type == 'sync-post':

            @self.router.post(f'/{name}')
            def syncpost(item: _Item):
                return attr(*item.args, **item.kwargs)
        elif type == 'property':

            @self.router.get(f'/_get_{name}')
            def get():
                return getattr(self.obj, name)

            @self.router.put(f'/_set_{name}')
            def syncpost(item: _Item):
                setattr(self.obj, name, item.args[0])
                return {'message': f'set {name} to {item}.'}
        elif type == 'readonly':

            @self.router.get(f'/{name}')
            def get():
                return getattr(self.obj, name)


class FastAPIServer(BasicObject):
    app = Instance(FastAPI)
    objs = Dict
    port = Int
    logs = Instance(Queue)
    wsq = Instance(Queue)

    def __init__(self, objs, port, name=None):
        self.objs = objs
        self.port = port
        self.logs = Queue()
        super().__init__(name=name)

        # create FastAPI app
        @asynccontextmanager
        async def lifespan(app: FastAPI):
            logodir = Path(__file__).parent.parent / 'logo'

            @app.get('/')
            async def root():
                return FileResponse(logodir / 'tapy.png')

            @app.get('/favicon.ico', include_in_schema=False)
            async def favicon():
                return FileResponse(logodir / 'favicon.ico')

            @app.get('/logger')
            async def logger():
                return StreamingResponse(stream_logs(self.logs), media_type='text/event-stream')

            self.logger.info('Startup hook')
            for id, obj in objs.items():
                subapi = SubAPI(obj, f'/{id}', self.logs)
                app.include_router(subapi.router)
                self.logger.info(f'Registered {obj.name} at /{id}.')
            self.logger.info('Done.')
            yield
            self.logger.info('Shutting down.')

        self.app = FastAPI(lifespan=lifespan)

    async def run(self):
        config = uvicorn.Config(app=self.app, port=self.port, host='0.0.0.0', log_level='info')
        server = uvicorn.Server(config)
        await server.serve()
