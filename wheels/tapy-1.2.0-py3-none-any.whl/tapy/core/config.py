"""Contains functions to obtain environment and OS information."""

import os
import platform
import sys
from importlib import import_module, metadata

_PACKAGES = {
    'ACOULAR': lambda: import_module('acoular').__version__,
    'H5PY': lambda: import_module('h5py').__version__,
    'SINUS': lambda: _get_sinus_lib()[1],
    'SOUNDDEVICE': lambda: import_module('sounddevice').__version__,
}


class DependencyMissingError(ImportError):
    """Raised when optional packages are required but are not installed."""

    def __init__(self, dependency, msg=None):
        self.dependency = dependency
        super().__init__(msg or f'Optional dependency {dependency} required.')


class Config:
    def __init__(self):
        super().__init__()
        self.ON_MACOS = 'Darwin' in platform.system()
        self.ON_LINUX = 'Linux' in platform.system()
        self.ON_WINDOWS = sys.platform in ('win32', 'cygwin')
        self.HOSTNAME = platform.node()
        self.PYTHON_VERSION = f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}'
        self.KNOWN_HOSTS = ('compute2', 'compute4', 'tap-doener', 'tornado', 'typhoon')
        self.SERVERS = {
            'mongodb': {'host': 'compute4', 'port': 27017},
            'turntable': {'host': 'tap-doener', 'port': 4001},
        }

    @property
    def version(self):
        return metadata.version('tapy')

    def __getattr__(self, name):
        if name.startswith('HAVE_'):
            package = name[len('HAVE_') :]
        elif name.endswith('_VERSION'):
            package = name[: -len('_VERSION')]
        else:
            raise AttributeError

        # package = package.lower()
        if package in _PACKAGES:
            try:
                version = _PACKAGES[package]()
            except (ImportError, OSError):
                version = False

            if version is not None and version is not False:
                setattr(self, 'HAVE_' + package, True)
                setattr(self, package + '_VERSION', version)
            else:
                setattr(self, 'HAVE_' + package, False)
                setattr(self, package + '_VERSION', None)
        else:
            raise AttributeError

        return getattr(self, name)

    def require(self, dependency):
        dependency = dependency.upper()
        if not getattr(self, f'HAVE_{dependency}'):
            raise DependencyMissingError(dependency)

    def __repr__(self):
        status = {
            p: (lambda v: 'missing' if not v else 'present' if v is True else v)(getattr(self, p + '_VERSION'))
            for p in _PACKAGES
        }
        key_width = max(len(p) for p in _PACKAGES) + 2
        package_info = [f'{p + ":":{key_width}} {v}' for p, v in sorted(status.items())]
        separator = '-' * max(map(len, package_info))
        package_info = '\n'.join(package_info)
        info = (
            f'TAPy Version {self.version}\n\n'
            + f'Python {self.PYTHON_VERSION} on {platform.platform()}\n\n'
            + 'External Packages\n'
            + f'{separator}\n'
            + f'{package_info}'
        )
        return info


config = Config()


def _get_sinus_lib():
    import ctypes
    import subprocess

    from packaging.version import Version

    try:
        # allow mocking for docs building
        if os.environ.get('MOCK_SINUS', '0') == '1':
            lib = None
            version = '0.0.mock'
        elif config.ON_LINUX:
            soname = 'libSinusInterface.so'
            lib = ctypes.cdll.LoadLibrary(soname)
            assert lib.__class__.__name__ == 'CDLL'
            assert lib._name == soname
            dpkg = subprocess.Popen(('dpkg', '-l'), stdout=subprocess.PIPE)
            result = str(subprocess.check_output(('grep', 'sinus'), stdin=dpkg.stdout))
            version = Version(str(result.split('sinus-driver')[1].strip().split('amd64')[0].strip()))
        elif config.ON_WINDOWS:
            lib = ctypes.windll.SINUSInterface
            assert lib.__class__.__name__ == 'WinDLL'
            assert lib._name == 'SINUSInterface'
            version = 'Unknown'
        elif config.ON_MACOS:
            raise OSError('OSX not supported, yet.')
    except OSError as e:
        raise e
    return lib, version
