"""Includes TAPy's abstract classes and core functionalities.

.. autosummary::
    :toctree: generated/

    base
    config
    connect
    logger
    server
"""

import asyncio
from threading import Thread


def _start_async():
    """Start the tapy async thread."""
    loop = asyncio.new_event_loop()
    Thread(target=loop.run_forever, daemon=True).start()
    return loop


#: The tapy async loop running in a separate thread.
LOOP = _start_async()


def submit_async(awaitable):
    """Submit an awaitable to the tapy async loop."""
    if asyncio.iscoroutine(awaitable):
        return asyncio.run_coroutine_threadsafe(awaitable, LOOP)
    elif asyncio.iscoroutinefunction(awaitable):
        return asyncio.run_coroutine_threadsafe(awaitable(), LOOP)
    else:
        raise TypeError(f'Expected coroutine or coroutine function, got {type(awaitable)}')
