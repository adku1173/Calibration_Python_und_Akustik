"""Contains classes for connecting to remote servers."""

import json
import logging
import subprocess
from contextlib import nullcontext
from functools import partial
from pathlib import Path

import aiohttp
import requests
from pymongo import MongoClient
from pymongo.errors import InvalidOperation, PyMongoError
from sshtunnel import SSHTunnelForwarder
from traits.api import Bool, Callable, Dict, Either, Instance, Int, List, Property, Str
from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed

from tapy.core import submit_async
from tapy.core.base import BasicObject
from tapy.core.config import config
from tapy.core.logger import getLogger


def system_call(cmd, logger):
    try:
        return subprocess.check_output(cmd, stderr=subprocess.STDOUT, shell=True, universal_newlines=True)
    except (OSError, subprocess.CalledProcessError) as exc:
        logger.error(exc.output[:-1])


class SSHConnection(BasicObject):
    """Class that establishes and manages SSH connections and port forwarding.

    It is assumed that the SSH username is identical to the username of the local machine.
    A different username can be supplied by passing
    `sshtunnel_kwargs={'ssh_username': <ssh_username>}`.
    Furthermore, a private ssh key must be used for authentication instead of a password.
    It is assumed that the key resides in `~/.ssh` and does not need a password. A different path
    and a potential key password can be supplied via the `sshtunnel_kwargs` argument.
    It is assumed that the public key has already been copied to the host. If not, it can be added by

    >>> ssh-copy-id -i ~/.ssh/mykey user@host

    It is strongly advised to use an ssh key instead of a password. If a password is needed for some
    obscure reason, it can be in principle passed via `sshtunnel_kwargs` as well.

    Parameters
    ----------
    ip_address_or_host : tuple or str
        IP or hostname of the remote gateway.
        It may be a two-element `tuple` `(str, int)` representing IP and port respectively,
        or a `str` representing the IP address only.
    remote_bind_addresses : (list of) tuple, optional
        Tuple (`str`, `int`) or list of tuples representing the private IP and ports of the remote
        side of the tunnel. The string of the private IP should be set to '127.0.0.1' or 'localhost'
        for most applications.
    local_bind_addresses : (list of) tuple, optional
        Local port definition of the tunnel. See `remote_bind_addresses`.
    sshtunnel_kwargs : dict, optional
        Dictionary of keyword arguments to pass to `SSHTunnelForwarder.__init__`. This can be used
        to define non-standard user, passwords, private keys etc.
        See `sshtunnel.SSHTunnelForwarder` for an exhaustive list of permissible arguments.
    remote_paths : (list of) str or `Path`, optional
        Path of directories at the remote machine that should be mounted as a local filesystem.
        If both `remote_paths` and `local_paths` are not `None`, the file system will be mounted.
        Please use absolute paths.
    local_paths : (list of) str or `Path`, optional
        Path of a local directory that the remote filesystem should be mounted at.
        If both `remote_path` and `local_path` are not `None`, the file system will be mounted.
        Please use absolute paths.
    persist : bool, optional
        Whether the connection should be closed if the context is left. Defaults to `True` which
        means that the connections are left open even outside of the context per default. The
        context then only serves as a check and reopens the connections if they have been lost.
        This should be set to `True` in most cases to avoid accidental closing of connections that
        happens with nested contexts.
    name : str, optional
        The name of the object. This will be used for logging purposes.
    """

    _server = Either(None, Instance(SSHTunnelForwarder))
    _port_forwarding = Bool(False)
    _mount_remote_fs = Bool(False)
    _ip_address_or_host = Str
    local_paths = Either(None, List(Path))
    remote_paths = Either(None, List(Path))
    persist = Bool
    _sshtunnel_kwargs = Either(None, Dict)

    def __init__(
        self,
        ip_address_or_host,
        remote_bind_addr=None,
        local_bind_addr=None,
        remote_paths=None,
        local_paths=None,
        persist=True,
        ssh_port=22,
        sshtunnel_kwargs=None,
        name=None,
    ):
        if remote_bind_addr is not None and local_bind_addr is not None:
            remote_bind_addr = remote_bind_addr if isinstance(remote_bind_addr, list) else [remote_bind_addr]
            local_bind_addr = local_bind_addr if isinstance(local_bind_addr, list) else [local_bind_addr]
            assert len(remote_bind_addr) == len(local_bind_addr)
            self._port_forwarding = True
        if local_paths is not None and remote_paths is not None:
            remote_paths = remote_paths if isinstance(remote_paths, list) else [remote_paths]
            local_paths = local_paths if isinstance(local_paths, list) else [local_paths]
            assert len(remote_paths) == len(local_paths)
            remote_paths, local_paths = [Path(p) for p in remote_paths], [Path(p) for p in local_paths]
            self._mount_remote_fs = True
        self.remote_paths, self.local_paths = remote_paths, local_paths
        if name is None:
            name = f'SSHTunnel({ip_address_or_host}:{ssh_port})'
        self._ip_address_or_host = ip_address_or_host
        if ip_address_or_host in config.KNOWN_HOSTS:
            ip_address_or_host += '.akustik.tu-berlin.de'
        ip_address_or_host = (ip_address_or_host, ssh_port)
        super().__init__(name=name)

        if sshtunnel_kwargs is None:
            sshtunnel_kwargs = dict()
        self.persist = persist
        self._sshtunnel_kwargs = sshtunnel_kwargs
        if self._port_forwarding:
            self._server = SSHTunnelForwarder(
                ip_address_or_host,
                remote_bind_addresses=remote_bind_addr,
                local_bind_addresses=local_bind_addr,
                **sshtunnel_kwargs,
                logger=getLogger('SSHTunnel', level='WARNING'),
            )

    def _connect(self):
        with self.logger.info('Establishing SSH Tunnel ...'):
            self._server.start()
        self.logger.debug(f'Opened SSH Tunnel {self._server.tunnel_bindings}.')

    def _disconnect(self):
        with self.logger.info('Disconnecting SSH Tunnel ...'):
            self._server.stop()

    def _is_mounted(self):
        all_mounted = all([p.is_mount() for p in self.local_paths])
        if all_mounted:
            self.logger.debug('All SSH filesystems are mounted.')
        return all_mounted

    def __enter__(self):
        if self._port_forwarding and not self._server.is_active:
            self._connect()
        if self._mount_remote_fs:
            for rp, lp in zip(self.remote_paths, self.local_paths, strict=False):
                if lp.is_mount():
                    self.logger.debug(f'{lp} is already mounted.')
                else:
                    with self.logger.info('Mounting remote file system ...'):
                        cmd = f'{self._ip_address_or_host}:{rp} {lp}'
                        if self._sshtunnel_kwargs.get('ssh_username') is not None:
                            cmd = self._sshtunnel_kwargs.get('ssh_username') + '@' + cmd
                        system_call('sshfs ' + cmd, self.logger)
                    self.logger.info(f'Mounted external filesystem ({self._ip_address_or_host}:{rp}) at {lp}')

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not self.persist:
            self.cleanup()

    def cleanup(self):
        if self._port_forwarding:
            self._disconnect()
        if self._mount_remote_fs:
            with self.logger.info('Unmounting remote file systems ...'):
                for lp in self.local_paths:
                    system_call(f'fusermount -u {lp}', self.logger)


class FastAPIObject(BasicObject):
    socket = Str
    ssh_connection = Either(Instance(nullcontext), Instance(SSHConnection))

    def __init__(self, host, port, id, ssh_connection=None):
        self.ssh_connection = nullcontext() if ssh_connection is None else ssh_connection
        url = f'http://{host}:{port}/{id}'
        self.socket = f'ws://{host}:{port}/{id}/ws/{config.HOSTNAME}'
        with self.ssh_connection:
            endpoints = requests.get(url + '/endpoints')
            data = endpoints.json()
            for d in data:
                if d['name'] in (id, 'uid', 'logger'):
                    pass
                elif d['name'] == 'name':
                    name = self.fastapi_get(url + '/_get_name') + f'(@{url})'
                elif d['type'] == 'async-post':
                    self.add_trait(d['name'], Callable(partial(self.fastapi_asyncpost, f'{url}/{d["name"]}')))
                elif d['type'] == 'sync-post':
                    self.add_trait(d['name'], Callable(partial(self.fastapi_syncpost, f'{url}/{d["name"]}')))
                elif d['type'] == 'property':
                    self.add_trait(
                        d['name'],
                        Property(
                            fget=partial(self.fastapi_get, f'{url}/_get_{d["name"]}'),
                            fset=partial(self.fastapi_set, f'{url}/_set_{d["name"]}'),
                        ),
                    )
                elif d['type'] == 'readonly':
                    self.add_trait(d['name'], Property(fget=partial(self.fastapi_get, f'{url}/{d["name"]}')))

        super().__init__(name=name)
        submit_async(self._listen)

    async def fastapi_asyncpost(self, path, *args, **kwargs):
        with self.ssh_connection:
            async with aiohttp.ClientSession() as session:
                response = await session.post(path, json={'args': args, 'kwargs': kwargs})
            await session.close()
        return response

    def fastapi_syncpost(self, path, *args, **kwargs):
        with self.ssh_connection:
            response = requests.post(path, json={'args': args, 'kwargs': kwargs}).json()
        return response

    def fastapi_get(self, path):
        with self.ssh_connection:
            response = requests.get(path).json()
        return response

    def fastapi_set(self, path, *args, **kwargs):
        args = None if len(args) == 1 else args[1:]  # need to pop "self"
        with self.ssh_connection:
            response = requests.put(path, json={'args': args, 'kwargs': kwargs}).json()
        return response

    async def _listen(self):
        self.logger.info(f'Listening on {self.socket}.')
        with self.ssh_connection:
            async for websocket in connect(self.socket):
                self.logger.debug(f'Registered as {websocket.local_address}.')
                try:
                    while True:
                        data = await websocket.recv()
                        message = json.loads(data)
                        message = logging.makeLogRecord(message)
                        if message.levelno >= self.logger.level:
                            message.name += f'@{self.ssh_connection._ip_address_or_host}'
                            self.logger.handle(message)
                except ConnectionClosed:
                    continue


class MongoDBConnection(BasicObject):
    """Class that establishes and manages MongoDB connections."""

    _client = Instance(MongoClient)
    host = Str
    port = Int
    persist = Bool
    ssh_connection = Either(SSHConnection, None)

    def __init__(self, host='localhost', port=27017, ssh_connection=None, persist=False, name=None):
        super().__init__(name)
        self.host = host
        self.port = port
        self.ssh_connection = ssh_connection
        self.persist = persist

    def _connect(self):
        with self.logger.info('Establishing MongoDB client connection ...'):
            self._client = MongoClient(self.host, self.port)
            self.logger.debug(self._client)

    def _disconnect(self):
        with self.logger.info('Closing MongoDB client connection ...'):
            self._client.close()

    def _is_connected(self):
        try:
            self._client.admin.command('ismaster')
            status = True
        except (AttributeError, InvalidOperation):
            status = False
        except PyMongoError as err:
            self.logger.error(f'Client unavailable. {err}')
            status = False
        if status:
            self.logger.debug('MongoDB client is up.')
        return status

    def __enter__(self):
        if self.ssh_connection is not None:
            self.ssh_connection.__enter__()
        if not self._is_connected():
            self._connect()

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.ssh_connection is not None:
            self.ssh_connection.__exit__(exc_type, exc_val, exc_tb)
        if not self.persist:
            self._disconnect()
