"""Contains `Acoular <http://acoular.org/>`_ compatible classes."""

import numpy as np
from traits.api import Bool, CInt, Float, Instance, Int, Property

from tapy.core.config import config
from tapy.devices.sinus import SinusDevice
from tapy.drivers.sinus import SINUS_STREAM, SinusStreamContext

if config.HAVE_ACOULAR:
    from acoular import SamplesGenerator

    class SinusSamplesGenerator(SamplesGenerator):
        """Class for reading samples from SINUS device.

        Returns signal data from enabled analog input channels.
        
        Examples:
        ---------
        >>> from tapy.devices.sinus import Apollo
        >>> from tapy.bindings.acoular import SinusSamplesGenerator
        >>> import acoular as ac
        >>> apollo = Apollo(inventory_no='TA132')
        >>> for ch in apollo.analog_inputs:
        >>>     ch.ENABLED = '1'
                ch.set_settings()
        >>> sg = SinusSamplesGenerator(device=apollo, num_samples=256)
        >>> data = ac.tools.return_result(sg, num=256)
        >>> print(data.shape)
        (256, 4)
        """

        #: SINUS device instance (e.g. Apollo, Tornado, Typhoon)
        device = Instance(SinusDevice)

        #: context manager for running the SINUS stream
        context = Instance(SinusStreamContext)

        #: Number of analog input channels for data collection.
        num_channels = Property(depends_on=['_num_channels'])

        #: Number of samples to collect; defaults to -1.
        # If set to -1, device collects until user breaks result function with collectsamples trait
        num_samples = CInt(-1, desc='number of samples to collect')

        #: Sampling frequency of the signal
        sample_freq = Property(depends_on=['_sample_freq'])

        #: Indicates if samples are collected, helper trait to break result function
        collectsamples = Bool(True, desc='Indicates if samples are collected')

        _enabled_analog_inputs = Property(desc='List of enabled analog inputs')

        _num_channels = Int()

        _sample_freq = Float()

        def _get__enabled_analog_inputs(self):
            c = [ch for ch in self.device.analog_inputs if ch.ENABLED == '1']
            self._num_channels = len(c)
            if self._num_channels == 0:
                self._sample_freq = float(self.device.analog_inputs[0].SampleRate)
            else:
                self._sample_freq = float(c[0].SampleRate)
            return c

        def _assert_num_valid(self, num, spb):
            if num < spb:
                raise OSError(f'block size is smaller than buffer block! Use at least: {spb}')
            elif not num % spb == 0:
                raise OSError(f'num need to be a multiple of {spb}')

        def _get_sample_freq(self):
            return self._sample_freq

        def _get_num_channels(self):
            return self._num_channels

        def result(self, num):
            """Python generator that yields the output block-wise.

            Use at least a block-size of one ring buffer block.

            Parameters
            ----------
            num : integer
                This parameter defines the size of the blocks to be yielded
                (i.e. the number of samples per block).

            Returns
            -------
            Samples in blocks of shape (num, :attr:`num_channels`).
                The last block may be shorter than num.
            """
            self.collectsamples = True
            if self.num_samples == -1:
                num_total = np.inf
            else:
                num_total = self.num_samples
            num_sum = 0

            channels = self._enabled_analog_inputs
            nc = len(channels)
            block_count = int(self.device.pci[0].BlockCount)
            spb = int(channels[0].BUFFER['SamplesPerBlock'])
            num_blocks = num//spb
            calib = SINUS_STREAM._analog_input_calibration_factor(channels)
            # buffer indices of all channels
            buffer_indices = [int(ch.BUFFER['BufferIndex']) for ch in channels]
            data = np.empty((num, nc), dtype=np.float64)

            # check for invalid arguments and settings
            self._assert_num_valid(num, spb)

            # start processing
            if self.context is None:
                context = SinusStreamContext(channels)
            else:
                context = self.context
            with context:
                context.start()
                while (num_sum < num_total) and self.collectsamples:
                    rp, wp = SINUS_STREAM._get_pointer_position(buffer_indices[0])
                    SINUS_STREAM._pdiff_in = SINUS_STREAM._calc_pointer_distance(rp, wp, block_count)
                    if SINUS_STREAM._pdiff_in >= num_blocks:
                        anz = min(num, num_total-num_sum)
                        SINUS_STREAM._read_buffer(data, num_blocks, rp, buffer_indices)
                        yield data[:anz]*calib
                        num_sum += anz
