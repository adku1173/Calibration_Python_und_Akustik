import array
import struct
from ctypes import *
from enum import Enum as E
from enum import unique

from packaging.version import Version
from traits.api import Dict, Either, Instance, Int, Str

from tapy.core.base import BasicObject
from tapy.core.config import _get_sinus_lib

latest_sinus_driver_version = Version('6.2.19')


@unique
class BUFFERCOMMANDS(E):
    """ENUM class for ByIndex commands."""

    count = 5
    WRITEPTR, READPTR, SAMPLESPERBLOCK, DATADIMENSION, DATAFORMAT = range(count)


@unique
class DATATYPES(E):
    """ENUM class for data types."""

    count = 18
    S_INT8, S_UINT8, S_INT16, S_UINT16, S_UINT16BIT, S_SCINT16, S_INT32, S_UINT32, S_FLOAT32, \
        S_GPS_BUF, S_ISO8601, S_MAS_TRG_BUF, S_INT64, S_UINT64, S_EGPS_BUF, S_DOUBLE, S_CHAR, \
        S_UINT32BIT = range(count)


class SINUSIF(BasicObject):
    """This class maps the Sinus driver to Python by using the `ctypes` library.

    The SINUSIF is a singelton and should not be instatiated by the user.
    An instance of that class can be accessed with TAPy:

    >>> from tapy.drivers.sinus import SINUS
    >>> SINUS.QueryDevices() # query the number of PCI devices

    The SINUSIF class implements several low level routines. It is not intended to use this
    class directly. Rather the user should rely on the high level classes :class:`tapy.drivers.sinus.SinusPCICard`
    and :class:`tapy.drivers.sinus.SinusAnalogChannel`.

    Parameters
    ----------
    name : str, optional
        The name of the object. This will be used for logging purposes.

    """
    driver_version = Either(Instance(Version), Str, None)
    device_index = Dict(key_trait=Str, value_trait=Int)
    num_devices = Int

    def __init__(self, name=None):
        super().__init__(name=name)
        with self.logger.info2('Initializing the Sinus interface. This can take up to 30 seconds.'):
            try:
                lib, self.driver_version = _get_sinus_lib()
                self.logger.driver(f'Found .so as {lib}')
                if isinstance(self.driver_version, Version) and self.driver_version < latest_sinus_driver_version:
                    self.logger.warning(f'Outdated driver version! (latest: {latest_sinus_driver_version})')
                if lib is None:
                    self.logger.info('Mocking SINUS library.')
                    return
            except OSError as e:
                self.logger.error(e)

            # typedef long (__stdcall *QUERYDEVICES) ();
            self._libQueryDevices = lib.QueryDevices
            self._libQueryDevices.restype = c_long
            # typedef long (__stdcall *SELECTDEVICE) (unsigned long dwDesiredDevice);
            self._libSelectDevice = lib.SelectDevice
            self._libSelectDevice.argtypes = [c_ulong]
            self._libSelectDevice.restype = c_long
            # typedef long (__stdcall *OPENDEVICE) ();
            self._libOpenDevice = lib.OpenDevice
            self._libOpenDevice.restype = c_long
            # typedef long (__stdcall *CLOSEDEVICE) ();
            self._libCloseDevice = lib.CloseDevice
            self._libCloseDevice.restype = c_long
            # typedef long (__stdcall *GETCHANNELNAME) (int Index, char* Name);
            self._libGetChannelName = lib.GetChannelName
            self._libGetChannelName.restype = c_long
            self._libGetChannelName.argtypes = [c_long, c_char_p]
            # typedef long (__stdcall *GETPROPERTYNAME) (const char* Channel, int Index, char* Name);
            self._libGetPropertyName = lib.GetPropertyName
            self._libGetPropertyName.restype = c_long
            self._libGetPropertyName.argtypes = [c_char_p, c_long, c_char_p]
            # typedef long (__stdcall *GETSETTINGNAME) (const char* Channel, const char* Property, int Index, char* Name);
            self._libGetSettingName = lib.GetSettingName
            self._libGetSettingName.restype = c_long
            self._libGetSettingName.argtypes = [c_char_p, c_char_p, c_long, c_char_p]
            # typedef long (__stdcall *GETVALUENAME) (const char* Channel, const char* Property, const char* Setting, int Index, char* Name);
            self._libGetValueName = lib.GetValueName
            self._libGetValueName.restype = c_long
            self._libGetValueName.argtypes = [c_char_p, c_char_p, c_char_p, c_long, c_char_p]
            # typedef long (__stdcall *SETPROPERTYVALUE) (const char* Channel, const char* Property, const char* Value);
            self._libSetPropertyValue = lib.SetPropertyValue
            self._libSetPropertyValue.restype = c_long
            self._libSetPropertyValue.argtypes = [c_char_p, c_char_p, c_char_p]
            # typedef long (__stdcall *GETSELECTEDDEVICE) ();
            self._libGetSelectedDevice = lib.GetSelectedDevice
            self._libGetSelectedDevice.restype = c_long
            # typedef long (__stdcall *START) ();
            self._libStart = lib.Start
            self._libStart.restype = c_long
            # typedef long (__stdcall *STOP) ();
            self._libStop = lib.Stop
            self._libStop.restype = c_long
            # typedef long (__stdcall *GETBLOCKDATA) (const char* BufferName, const unsigned long dwStart, const unsigned long dwNbrOfBlocks, void* pData);
            self._libGetBlockData = lib.GetBlockData
            self._libGetBlockData.restype = c_long
            self._libGetBlockData.argtypes = [c_char_p, c_ulong, c_ulong, c_void_p]
            # typedef long (__stdcall *SETBLOCKDATA) (const char* BufferName, const unsigned long dwStart, const unsigned long dwNbrOfBlocks, void* pData);
            self._libSetBlockData = lib.SetBlockData
            self._libSetBlockData.restype = c_long
            self._libSetBlockData.argtypes = [c_char_p, c_ulong, c_ulong, c_void_p]
            # typedef long (__stdcall *GETBLOCKDATABYINDEX) (const unsigned long BufferIdx, const unsigned long dwStart, const unsigned long dwNbrOfBlocks, void* pData);
            self._libGetBlockDataByIndex = lib.GetBlockDataByIndex
            self._libGetBlockDataByIndex.restype = c_long
            self._libGetBlockDataByIndex.argtypes = [c_ulong, c_ulong, c_ulong, c_void_p]
            # typedef long (__stdcall *SETBLOCKDATABYINDEX) (const unsigned long BufferIdx, const unsigned long dwStart, const unsigned long dwNbrOfBlocks, void* pData);
            self._libSetBlockDataByIndex = lib.SetBlockDataByIndex
            self._libSetBlockDataByIndex.restype = c_long
            self._libSetBlockDataByIndex.argtypes = [c_ulong, c_ulong, c_ulong, c_void_p]
            # typedef long (__stdcall *GETBYINDEX) (const unsigned long BufferIdx, const BUFFERCOMMANDS Property);
            self._libGetByIndex = lib.GetByIndex
            self._libGetByIndex.restype = c_long
            self._libGetByIndex.argtypes = [c_ulong, c_ulong]
            # typedef long (__stdcall *GETHELP) (const char *Name, char *HelpMessage);
            self._libGetHelp = lib.GetHelp
            self._libGetHelp.restype = c_long
            self._libGetHelp.argtypes = [c_char_p, c_char_p]

            # a dictionary dict(key, value) where value is again a dictionary
            self._enabledChannels = {0: {'BlockCounter_001': {'bytesperblock': 0, 'arrayfmt': ''}}}

            # devices need to be queried once to avoid bugs !
            self.num_devices = self.QueryDevices()
            if self.num_devices:
                self.logger.info(f'Found {self.num_devices} devices.')
            else:
                self.logger.warning('Did not find any devices.')

            # construct serial -> device_index mapping
            self.device_index = {}
            for i in range(self.num_devices):
                self.SelectDevice(i)
                self.device_index[self.Get('Device', 'DESCRIPTION', 'SerialNumber')] = i

    def QueryDevices(self):
        """Returns the number of SINUS devices installed in the system."""
        return self._libQueryDevices()

    def SelectDevice(self, index=0):
        """Selects the device to work with from now on.
        :param index: the index of the desired device; default: 0.
        """
        return self._libSelectDevice(index)

    def GetSelectedDevice(self):
        """Returns the index of the currently selected device."""
        return self._libGetSelectedDevice()

    def OpenDevice(self):
        """Opens the selected device."""
        return self._libOpenDevice()

    def CloseDevice(self):
        """Closes the selected device."""
        return self._libCloseDevice()

    def Get(self, channel=None, prop=None, sett=None):
        """Gets information about the current device.
        :param channel: channel name
        :param prop: property name
        :param sett: setting name.

        Usage:
        Get() returns a list of channel names for the device
        Get(chname) returns a list of properties for the channel
        Get(chname, pname) returns a list of settings for the property
        Get(chname, pname, sname) returns the value/a list of values for the setting
        """
        d = create_string_buffer(1024)
        if channel is None:
            rc = self._libGetChannelName(0, d)
            if rc <= 0:
                self.logger.driver(f'GetChannelName Error {rc}')
                return ''
            if rc == 1:
                return d.value.decode('utf-8')
            s = [d.value.decode('utf-8')]
            for index in range(1, rc):
                self._libGetChannelName(index, d)
                s.append(d.value.decode('utf-8'))
            return s
        if prop is None:
            rc = self._libGetPropertyName(bytes(channel, 'utf-8'), 0, d)
            if rc <= 0:
                self.logger.driver(f'GetPropertyName Error {rc}')
                return ''
            if rc == 1:
                return d.value.decode('utf-8')
            s = [d.value.decode('utf-8')]
            for index in range(1, rc):
                self._libGetPropertyName(bytes(channel, 'utf-8'), index, d)
                s.append(d.value.decode('utf-8'))
            return s
        if sett is None:
            rc = self._libGetSettingName(bytes(channel, 'utf-8'), bytes(prop, 'utf-8'), 0, d)
            if rc <= 0:
                self.logger.driver(f'GetSettingName Error {rc}')
                return ''
            if rc == 1:
                return d.value.decode('utf-8')
            s = [d.value.decode('utf-8')]
            for index in range(1, rc):
                self._libGetSettingName(bytes(channel, 'utf-8'), bytes(prop, 'utf-8'), index, d)
                s.append(d.value.decode('utf-8'))
            return s
        rc = self._libGetValueName(bytes(channel, 'utf-8'), bytes(prop, 'utf-8'),
                                   bytes(sett, 'utf-8'), 0, d)
        if rc <= 0:
            self.logger.driver(f'GetValueName Error {rc}')
            return ''
        if rc == 1:
            return d.value.decode('utf-8')
        s = [d.value.decode('utf-8')]
        for index in range(1, rc):
            self._libGetValueName(bytes(channel, 'utf-8'), bytes(prop, 'utf-8'),
                                  bytes(sett, 'utf-8'), index, d)
            s.append(d.value.decode('utf-8'))
        return s

    def Set(self, channel, prop, value):
        """Set a property of a channel to a certain value.
        :param channel: channel name
        :param prop: property name
        :param value: the new value.
        """
        if prop.lower() == 'enabled':
            seldev = self.GetSelectedDevice()
            if seldev not in self._enabledChannels:
                self._enabledChannels[seldev] = {}
            if value == '1':
                rc = self._libSetPropertyValue(bytes(channel, 'utf-8'), b'Enabled', b'1')
                if rc == 0:
                    chidx = self.Get(channel, 'BUFFER', 'BufferIndex')
                    chidx = int(chidx)
                    # adding the same value as name and index keys;
                    # changing the value applies to both keys!
                    self._enabledChannels[seldev][channel] = self._enabledChannels[seldev][chidx] = \
                        {'bytesperblock': 0, 'arrayfmt': ''}
                return rc
            if value == '0':
                if channel in self._enabledChannels:
                    # we have to delete both channel name and index entries
                    chidx = self.Get(channel, 'BUFFER', 'BufferIndex')
                    chidx = int(chidx)
                    if channel in self._enabledChannels[seldev]:
                        del self._enabledChannels[seldev][channel]
                    if chidx in self._enabledChannels[seldev]:
                        del self._enabledChannels[seldev][chidx]
                return self._libSetPropertyValue(bytes(channel, 'utf-8'), b'Enabled', b'0')
        return self._libSetPropertyValue(bytes(channel, 'utf-8'), bytes(prop, 'utf-8'),
                                         bytes(value, 'utf-8'))

    def GetHelp(self, topic):
        """Returns a help string to a topic.
        :param topic: the topic in question.
        """
        answer = create_string_buffer(1024)
        rc = self._libGetHelp(bytes(topic, 'utf-8'), answer)
        if rc == 0:
            return answer.value.decode('utf-8')
        else:
            return 'Not found.'

    def Start(self):
        """Starts recording on the current device."""
        # TODO: Start modes

        # we need to keep information about all enabled channels for later;
        # this way we don't need to query this info in GetBlockData while running
        seldev = self.GetSelectedDevice()
        if 'BlockCounter_001' not in self._enabledChannels[seldev]:
            self.Set('BlockCounter_001', 'Enabled', '1')
        for channel in self._enabledChannels[seldev]:
            if isinstance(channel, int):
                continue  # ignore buffer indices as key
            spb = self.Get(channel, 'BUFFER', 'SamplesPerBlock')
            if spb == '':
                spb = 1
            else:
                spb = int(spb)
            dff = self.Get(channel, 'BUFFER', 'DataFormat')
            dim = self.Get(channel, 'BUFFER', 'DataDimension')
            if dim == '':
                dim = 1
            else:
                dim = int(dim)
            if dff in ('CHAR', 'INT8'):
                numbytes = 1
                arrayfmt = 'b'
            elif dff == 'UINT8':
                numbytes = 1
                arrayfmt = 'B'
            elif dff in ('SCINT16', 'INT16'):
                numbytes = 2
                arrayfmt = 'h'
            elif dff == 'UINT16':
                numbytes = 2
                arrayfmt = 'H'
            elif dff == 'FLOAT32':
                numbytes = 4
                arrayfmt = 'f'
            elif dff == 'INT32':
                numbytes = 4
                arrayfmt = 'i'
            elif dff in ('UINT32', 'UINT32BIT'):
                numbytes = 4
                arrayfmt = 'I'
            elif dff == 'DOUBLE':
                numbytes = 8
                arrayfmt = 'd'
            elif dff == 'INT64':
                numbytes = 8
                arrayfmt = 'q'
            elif dff == 'UINT64':
                numbytes = 8
                arrayfmt = 'Q'
            elif dff == 'EGPS_BUF':
                # ulong BlockCnt, long DevTimeInc, 172*char Data (171 + align)
                numbytes = 180
                arrayfmt = 'Ll172s'
            elif dff == 'MAS_TRG_BUF':
                # ulong DevTimeInc, ulong BlockCnt, ulong EventCnt
                numbytes = 12
                arrayfmt = 'LLL'
            else:
                self.logger.driver('DataType not (yet) supported!')
                return None
            # changing the value for channel name also alters the index entry
            self._enabledChannels[seldev][channel]['bytesperblock'] = numbytes*spb*dim
            self._enabledChannels[seldev][channel]['arrayfmt'] = arrayfmt
        return self._libStart()

    def Stop(self):
        """Stops recording on the current device."""
        # TODO: Stop modes
        return self._libStop()

    def GetBlockData(self, channel, start, number):
        """Returns recorded data as array of the channels data format.
        The number of samples in 1 block is determined automatically.

        :param channel: the channel name to get the data from
        :param start: the first block to collect; ranges from 0 to Device->BlockCount
        :param number: number of blocks to collect
        """
        # TODO: dimension of the array
        seldev = self.GetSelectedDevice()
        bbb = self._enabledChannels[seldev][channel]['bytesperblock']
        fmt = self._enabledChannels[seldev][channel]['arrayfmt']
        if (channel in self._enabledChannels[seldev]) and (bbb > 0):
            d = create_string_buffer(bbb * number)
            rc = self._libGetBlockData(bytes(channel, 'utf-8'), start, number, d)
            if rc == 0:
                if len(fmt) > 1:
                    out = []
                    for i in range(number):
                        s = struct.unpack_from(fmt, d, i*bbb)
                        if bbb > 20:  # eGPS
                            out.append([s[0], s[1], s[2].decode().strip('\x00')])
                        else:
                            out.append(s)
                    return out
                # else:
                a = array.array(fmt, d.raw)
                return a.tolist()
            # else if rc <> 0:
            self.logger.driver('GetBlockData error!')
            return None
        # else if channel not in _enabledchannels:
        self.logger.driver('Channel not enabled!')
        return None

    def GetBlockDataByIndex(self, chidx, start, number):
        """Returns recorded data as array of the channels data format.
        The number of samples in 1 block is determined automatically.
        This is slightly faster than GetBlockData which uses the channel name as string.

        :param chidx: the buffer index of the channel
        :param start: the first block to collect; ranges from 0 to Device->BlockCount
        :param number: number of blocks to collect
        """
        seldev = self.GetSelectedDevice()
        bbb = self._enabledChannels[seldev][chidx]['bytesperblock']
        fmt = self._enabledChannels[seldev][chidx]['arrayfmt']
        if (chidx in self._enabledChannels[seldev]) and (bbb > 0):
            d = create_string_buffer(bbb*number)
            rc = self._libGetBlockDataByIndex(chidx, start, number, d)
            if rc == 0:
                if len(fmt) > 1:
                    out = []
                    for i in range(number):
                        s = struct.unpack_from(fmt, d, i*bbb)
                        if bbb > 20:  # eGPS
                            out.append([s[0], s[1], s[2].decode().strip('\x00')])
                        else:
                            out.append(s)
                    return out
                # else:
                a = array.array(fmt, d.raw)
                return a.tolist()
            # else:
            self.logger.driver('GetBlockDataByIndex error!')
            return None
        # else:
        self.logger.driver('Channel not enabled!')
        return None

    def GetByIndex(self, chidx, cmd):
        """Fast access to some important channel properties needed while recording.
        Fast because it uses the buffer index instead of the name, and the BUFFERCOMMANDS
        enum instead of property strings.
        :param chidx: the buffer index of the channel
        :param cmd: the buffer command (or property, if you like).
        """
        if cmd < BUFFERCOMMANDS.count.value:
            return self._libGetByIndex(chidx, cmd)
        self.logger.driver('Unknown command!')
        return None

    def SetBlockData(self, channel, start, number, putdata):
        """Puts output data as array of the channels data format.
        The number of samples in 1 block is determined automatically.
        putdata must be a byte array!.

        :param channel: the channel name to get the data from
        :param start: the first block to collect; ranges from 0 to Device->BlockCount
        :param number: number of blocks to collect
        :param putdata: byte array of values
        """
        # TODO: dimension of the array
        if channel in self._enabledChannels[self.GetSelectedDevice()]:
            d = create_string_buffer(putdata)
            rc = self._libSetBlockData(bytes(channel, 'utf-8'), start, number, d)
            return rc
        # else if channel not in enabledchannels:
        self.logger.driver('Channel not enabled!')
        return -1

    def SetBlockDataByIndex(self, chidx, start, number, putdata):
        """Puts output data as array of the channels data format.
        The number of samples in 1 block is determined automatically.
        putdata must be a byte array!.

        :param chidx: the buffer index of the channel
        :param start: the first block to collect; ranges from 0 to Device->BlockCount
        :param number: number of blocks to collect
        :param putdata: byte array of values
        """
        # TODO: dimension of the array
        if chidx in self._enabledChannels[self.GetSelectedDevice()]:
            d = create_string_buffer(putdata)
            rc = self._libSetBlockDataByIndex(chidx, start, number, d)
            return rc
        # else if channel not in enabledchannels:
        self.logger.driver('Channel not enabled!')
        return -1


SINUS = SINUSIF(name='SinusC++Wrapper')
