"""Includes classes that serve as adapters to other Python packages.

.. autosummary::
    :toctree: generated/

    acoular
    sinus
"""
