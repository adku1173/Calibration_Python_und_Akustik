"""Contains driver class for the OutlineET2 turntable. To be used as a server on tap-doener."""

from tapy.core.config import config

if config.HOSTNAME == 'tap-doener':
    import asyncio
    import time
    from functools import wraps

    import numpy as np
    from adafruit_motorkit import MotorKit
    from RPi import GPIO
    from traits.api import Enum, Float, Instance, Int, Property

    from tapy.core.base import BasicObject

    def do_if_idle(msg):
        def decorator(method):
            @wraps(method)
            async def _impl(self, *args, **kwargs):
                if self.is_idle:
                    return await method(self, *args, **kwargs)
                else:
                    self.logger.error(msg)

            return _impl

        return decorator

    class OutlineET2(BasicObject):
        position = Property(desc='Get the current position of the turntable.')
        throttle = Property
        turn_direction = Enum('shortest', 'cw', 'ccw')
        blc = Enum('cw', 'ccw', 'off')
        step = Float(2.5)
        _kit = Instance(MotorKit)
        homing_speed = Float(0.4)
        _position = Float
        _pin_zero = Int(21)
        _pin_step = Int(19)

        is_home = Property
        is_step_high = Property
        is_idle = Property

        def __init__(self, step=2.5, turn_direction='shortest', blc='ccw', homing_speed=0.4, name=None):
            """
            Initialize the OutlineET2 instance.

            Parameters
            ----------
                pin_step (int): GPIO pin for step signal
                pin_zero (int): GPIO pin for zero signal
                step (float): angle moved per step in degrees
                turn_direction (str): shortest by default, clockwise (cw) or counterclockwise (ccw)

            """
            super().__init__(name)
            assert turn_direction in ('shortest', 'cw', 'ccw')
            self.turn_direction = turn_direction
            self.step = step
            self._kit = MotorKit()
            self.throttle = 0
            self.blc = blc
            self._init_gpio()
            self.homing_speed = homing_speed
            try:
                with open('last-position.txt', 'rb') as file:
                    self._position = float(file.read())
            except FileNotFoundError:
                pass

        def _init_gpio(self):
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(self._pin_step, GPIO.IN)
            GPIO.setup(self._pin_zero, GPIO.IN)
            GPIO.setup(1, GPIO.OUT)
            GPIO.output(1, GPIO.HIGH)

        def _get_position(self):
            return self._position

        def _set_position(self, value):
            """
            Set the current position and save it to txt file.

            Parameters
            ----------
            value (float): Position in degrees.
            """
            self.logger.driver(f'Setting pos to {value}')
            self._position = value % 360
            with open('last-position.txt', 'w') as file:
                file.write(str(self._position))

        def _get_throttle(self):
            return self._kit.motor1.throttle

        def _set_throttle(self, throttle):
            self._kit.motor1.throttle = -throttle

        def _get_is_home(self):
            return GPIO.input(self._pin_zero)

        def _get_is_step_high(self):
            return GPIO.input(self._pin_step) == GPIO.HIGH

        def _get_is_idle(self):
            return self.throttle == 0

        def _calc_direction(self, target):
            diff = (target - self.position) % 360
            if self.turn_direction == 'shortest' and diff > 180 or self.turn_direction == 'ccw' and diff != 0:
                diff -= 360
            return int(np.sign(diff))

        @do_if_idle('Homing could not be executed. Device is not Idle.')
        async def homing(self):
            """Move to home position, zero degrees."""
            if self.is_home:
                self.logger.info('Already home!')
                self.position = 0
            else:
                with self.logger.info('Homing ...'):
                    direction = self._calc_direction(0)
                    # check needed if last position is zero but turntable is not at zero
                    self.throttle = direction * self.homing_speed if direction != 0 else self.homing_speed
                while not self.is_home:
                    time.sleep(0.01)
                # time.sleep(0.1)
                self.throttle = 0
                self.position = 0
                self.logger.driver(f'Step: {self.is_step_high}')

        def _parse_target(self, target):
            steps = target / self.step
            rsteps = round(steps, 0)
            if steps - rsteps:
                self.logger.warning(
                    f'Can only move in {self.step}° steps! '
                    f'Rounding to nearest angle ({self.step * rsteps}°) and proceeding.'
                )
            return self.step * rsteps % 360

        @do_if_idle('Move command could not be exectued. Device is not Idle.')
        async def _move(self, angle, speed):
            self.logger.driver(f'Step: {self.is_step_high}')
            direction = self._calc_direction(angle)
            self.throttle = direction * speed
            step_in_progress = False
            self.logger.driver(f'Step: {self.is_step_high}')
            while self.position != angle:
                self.logger.driver(f'Step: {self.is_step_high}')
                if not step_in_progress and self.is_step_high:
                    step_in_progress = True
                elif step_in_progress and not self.is_step_high:
                    self.position += direction * self.step
                    step_in_progress = False
                await asyncio.sleep(0.01)
            self.throttle = 0

        async def move_no_progress(self, angle, speed=0.4):
            if speed < 0.4:
                self.logger.warning('Speed is lower than 0.4, the turntable might not move at all!')
            with self.logger.info(f'Moving to {angle}° ...'):
                angle = self._parse_target(angle)
                direction = self._calc_direction(angle)
                if direction == 0:
                    self.logger.info('Already there.')
                elif (
                    self.blc == 'cw'
                    or (self.blc == 'off' and direction == 1)
                    or (self.blc == 'ccw' or (self.blc == 'off' and direction == -1))
                ):
                    await self._move(angle, speed)

        def __del__(self):
            """Stop motor and cleanup GPIOs."""
            self.throttle = 0
            GPIO.cleanup()


# git pull && touch pyproject.toml && systemctl restart tapy-server
