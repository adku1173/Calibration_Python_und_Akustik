"""Contains driver classes for low-level Sinus devices."""

import time
from contextlib import ContextDecorator, contextmanager
from functools import partial, wraps
from queue import Queue
from threading import Barrier, Event, Thread

import numpy as np
from pyfar import dsp
from pyfar.classes.audio import Signal
from traits.api import Bool, Either, Enum, Float, Instance, Int, List, Range, Str, Tuple

from tapy.bindings.sinus import SINUS
from tapy.core.base import BasicObject

##################################################################################################################################
# PCI SERIAL NUMBERS OF THE SINUS HARDWARE DEVICES
# DO NOT EDIT UNLESS PHYSICAL CONFIGURATION OF PCI CARDS CHANGES!
apollo_ta132_pci_serials = ('11284',)
apollo_ta181_pci_serials = ('11283',)
tornado_pci_serials = ('10142', '10112', '10125', '10126')
typhoon_pci_serials = (
    '10153',
    '10123',
    '10118',
    '10119',
    '10092',
    '10116',
    '10030',
    '10038',
    '10095',
    '10028',
    '10115',
    '10093',
)
##################################################################################################################################


class SinusError(Exception):
    """Generic Error for SINUS devices."""


class SinusDeviceStatusError(SinusError):
    """Exception raised when SINUS device status cannot be changed."""


class SinusDeviceConnectionError(SinusError):
    """Exception raised when SINUS device status is not connected."""


class SinusSynchronizationError(SinusError):
    """Exception raised when SINUS device synchronization fails."""


class SinusPlayRecError(SinusError):
    """Exception raised when an error related to SINUS IO occurs."""


class SinusDeviceContext(BasicObject):
    """Context manager that selects the chosen Sinus device and opens or closes it.

    This class can be used as a contextmanager:

    >>> from tapy.drivers.sinus import SINUS
    >>>
    >>> device_index = 0
    >>> open = SinusDeviceContext('Open', device_index)
    >>>
    >>> with open:
    >>>     pass

    Additionally, it can be used as a decorator inside of the device class

    >>> from tapy.devices.sinus import SinusDevice
    >>> from tapy.drivers.sinus import sinus_context
    >>>
    >>> class Foo(SinusDevice):
    >>>     @sinus_context
    >>>     def method(self):
    >>>         pass

    Parameters
    ----------
    status
        The device status to change the selected to ('Config' or 'Open').
    device_index
        The device_index to open. Defaults to `None`. When used inside a class,
        the first argument (`self`) of the method is automatically used to infer the device index.
    """

    device_context = Either(Str, None)
    device_index = Either(Int, None)

    def __init__(self, device_context=None, device_index=None):
        self.device_context = device_context
        self.device_index = device_index
        super().__init__()

    def __call__(self, method):
        @wraps(method)
        def decorated(*args, **kwargs):
            with SinusDeviceContext(args[0].device_context, args[0].device_index):
                return method(*args, **kwargs)

        return decorated

    def _change_device_status(self):
        if SINUS.SelectDevice(self.device_index) != 0:
            raise SinusDeviceStatusError(f'Cannot select device {self.device_index}).')

        current_status = SINUS.Get('Device', 'Status', 'DeviceStatus')[1]
        if self.device_context == current_status:
            return
        elif current_status == 'Config':
            self.logger.info(f'Opening device {self.device_index} ...')
            if SINUS.OpenDevice() != 0:
                raise SinusDeviceStatusError(f'Cannot open device {self.device_index}).')
        elif current_status == 'Open':
            self.logger.info(f'Closing device {self.device_index} ...')
            if SINUS.CloseDevice() != 0:
                raise SinusDeviceStatusError(f'Cannot close device {self.device_index}).')

    def __enter__(self):
        try:
            self._change_device_status()
        except SinusDeviceStatusError as err:
            self.logger.error(err)
        return self

    def __exit__(self, *exc):
        return False


sinus_context = SinusDeviceContext()


class SinusObject(BasicObject):
    """Base class for higher level drivers such as :class:`SinusPCICard` and `:class:`SinusAnalogChannel`.

    The class implements high-level routines such automatic creation of class attributes (traits) representing
    settable driver settings. Changes to the current setting can be applied via the :meth:`set_settings` method.
    """

    device_context = Str
    device_index = Int
    _settable_attr = List
    _sinus_key = Str

    def __init__(self, device_context, device_index, sinus_key=None, name=None):
        self.device_context = device_context
        self.device_index = device_index
        self._sinus_key = name if sinus_key is None else sinus_key
        super().__init__(name=name)

    def _build_settable_traits(self):
        for prop in SINUS.Get(self._sinus_key):  # ICP, GAIN, ...
            values = SINUS.Get(self._sinus_key, prop)
            if 'SettableAtStatus' and 'SetValues' in values:
                self._settable_attr.append(prop)
                setvalues = SINUS.Get(self._sinus_key, prop, 'SetValues')
                if prop == 'InputSource' and isinstance(self, SinusADCToDACChannel):
                    setvalues += ['Memory']  # not included in SetValues but can be a valid value
                self.add_trait(str(prop), Enum(SINUS.Get(self._sinus_key, prop, 'CurrentValue'), *setvalues))
            elif 'SettableAtStatus' and 'RANGE' in values:
                low, high = SINUS.Get(self._sinus_key, prop, 'Range')
                self.add_trait(
                    str(prop), Range(float(low), float(high), float(SINUS.Get(self._sinus_key, prop, 'CurrentValue')))
                )
            elif 'SetValues' not in values:
                pass
            else:
                raise NotImplementedError(f'cannot handle {prop} of {self._sinus_key}')

    def _build_readonly_traits(self):
        pass

    def _update_settable_traits(self):
        for prop in self._settable_attr:
            setattr(self, prop, SINUS.Get(self._sinus_key, prop, 'CurrentValue'))

    def _update_readonly_traits(self):
        pass

    @sinus_context
    def _build_traits(self):
        """Dynamically creates channel properties as trait attributes.

        Raises
        ------
        NotImplementedError
            Error raised if unknown channel properties appear, which are neither settable
            nor read-only.
        """
        self._build_settable_traits()
        self._build_readonly_traits()

    @sinus_context
    def _update_traits(self):
        self._update_settable_traits()
        self._update_readonly_traits()

    @sinus_context
    def set_settings(self, attribute=None):
        """Method that applies the current channel object setting.

        Raises
        ------
        ValueError
            Error raised by the Sinus Hardware driver
        """
        if attribute is not None and isinstance(attribute, str):
            attributes = [attribute]
        elif attribute is not None and isinstance(attribute, list):
            attributes = attribute
        else:
            attributes = self._settable_attr[:]
        for attr in attributes:
            new_value = getattr(self, attr)
            if new_value != SINUS.Get(self._sinus_key, attr, 'CurrentValue'):
                if attr == 'InputSource' and isinstance(self, SinusADCToDACChannel) and new_value != 'Memory':
                    new_value.split('_')[-1]
                    chnum = self.name.split('_')[-1]
                    if SINUS.Get(f'AnalogOutput_{chnum}', 'ENABLED', 'CurrentValue') == '1':
                        self.logger.warning(f'Output {chnum} is already in use by AnalogOutput_{chnum}.')
                        continue
                if SINUS.Set(self._sinus_key, attr, new_value) != 0:
                    self.logger.error(f'Could not set {attr} to {new_value}.')
                else:
                    new_value = f"'{new_value}'" if isinstance(new_value, str) else new_value
                    self.logger.driver(f"'{attr}' set to {new_value}.")
            else:
                self.logger.driver(f"'{attr}' is already {new_value}.")
        self._update_traits()  # in case related attributes change their value


class SinusADCToDACChannel(SinusObject):
    """Object for handling ADCToDAC channels.

    This class provides access to the ADCToDAC device channel settings. The :attr:`name` must follow the
    naming conventions of the Sinus driver. To create an ADCToDAC channel (e.g. channel one),
    the name of the object must be `ADCToDAC_001`. The object is intended to route the analog input
    channels to a dedicated output channel for listening to the input signal.
    Note that the PCI device must be in open mode to access the channels. For example:

    >>> from tapy.drivers.sinus import SINUS, SinusADCToDACChannel, SinusPCICard
    >>>
    >>> SINUS.SelectDevice(0)
    >>> SINUS.OpenDevice()
    >>> adctodac = SinusADCToDACChannel(name='ADCToDAC_001')

    A list of available channels can be seen by

    >>> SINUS.OpenDevice()
    >>> print(SINUS.Get('ADCToDAC_001'))

    Parameters
    ----------
    name : str
        The name of the channel (e.g. 'ADCToDAC_001').

    Attributes
    ----------
    name : str
        The name of the device.

    Notes
    -----
    Most attributes are built automatically during channel initilization when the class is instantiated.
    This includes properties such as:

    :attr:`InputSource`:
        The input channel to be routed to the output channel. For example 'AnalogInput_001'.
    :attr:`SampleRate`:
        The channel's sample rate in Hz. Settable values depend on the :attr:`Mode` of the corresponding
        :class:`tapy.devices.sinus.SinusPCICard` object.
    :attr:`ENABLED`:
        Determines if the channel's data is delivered by the driver. Settable values are {'0','1'}. This must be set to
        '1' in order to enable recording or playing signals.

    A full list of initialized attributes can be seen with

    >>> adctodac = SinusADCToDACChannel(name='ADCToDAC_001')
    >>> print(adctodac._settable_attr)
    """

    def __init__(self, device_index, sinus_key=None, name=None):
        super().__init__(device_context='Open', device_index=device_index, sinus_key=sinus_key, name=name)
        self._build_traits()
        self._update_traits()

    def __get_dict_attribute(self, attribute):
        d = {}
        keys = SINUS.Get(self._sinus_key, attribute)
        for k in keys:
            v = SINUS.Get(self._sinus_key, attribute, k)
            d.update({k: v})
        return d

    def _build_readonly_traits(self):
        # here we only build the 'BUFFER' dictionary
        props = SINUS.Get(self._sinus_key)
        if 'BUFFER' in props:
            self.add_trait('BUFFER', self.__get_dict_attribute(attribute='BUFFER'))

    def _update_readonly_traits(self):
        if hasattr(self, 'BUFFER'):
            self.BUFFER = self.__get_dict_attribute(attribute='BUFFER')


class SinusAnalogChannel(SinusObject):
    """Object for handling PCI channels such as analog inputs or analog outputs.

    This class provides access to the PCI device channel settings. The :attr:`name` must follow the
    naming conventions of the Sinus driver. To create an analog input channel (e.g. channel one),
    the name of the object must be `AnalogInput_001`. To create an analog output channel, the name
    of the object must be  `AnalogOutput_001`. Note that the PCI device must be in open mode to
    access the channels. For example:

    >>> from tapy.drivers.sinus import SINUS, SinusAnalogChannel, SinusPCICard
    >>>
    >>> SINUS.SelectDevice(0)
    >>> apollo = SinusPCICard(device_index=0)
    >>> SINUS.OpenDevice()
    >>> in = SinusAnalogChannel(name='AnalogInput_001')

    A list of available channels can be seen by

    >>> SINUS.OpenDevice()
    >>> print(SINUS.Get())

    Parameters
    ----------
    name : str
        The name of the channel (e.g. 'AnalogInput_001').
    sensitivity : float
        The senistivity of the device connected to the channel. Defaults to 1.

    Attributes
    ----------
    name : str
        The name of the device.
    sensitivity : float
        The senistivity of the device connected to the channel. Defaults to 1.

    Notes
    -----
    Most attributes are built automatically during channel initilization when the class is instantiated.
    This includes properties such as:

    :attr:`SampleRate`:
        The channel's sample rate in Hz. Settable values depend on the :attr:`Mode` of the corresponding
        :class:`tapy.devices.sinus.SinusPCICard` object.
    :attr:`ICP`:
        Switches the ICP for the input channel on or off. Settable values are {'0', '2mA', '4mA'}. '4mA' is
        only available when the Typhoon is used.
    :attr:`GAIN`:
        Input or output gain in dB. Settable values are {'-20', '0'}. A value of '0' sets the voltage range of the
        AD Converter to +-1 V, whereas '-20' corresponds to a voltage range of +-10 V.
        From Email communication with sinus: There is a headroom reserve of about 10%, and there are channels
        called PhysicalOverload that signal a potential overload and can be recorded in sync with the data to mark these
        phases later. To determine the exact clipping value is not easy, because it depends on different factors during
        operation.
    :attr:`ENABLED`:
        Determines if the channel's data is delivered by the driver. Settable values are {'0','1'}. This must be set to
        '1' in order to enable recording or playing signals.

    A full list of initialized attributes can be seen with

    >>> in = SinusAnalogChannel(name='AnalogInput_001')
    >>> print(in._settable_attr)
    """

    sensitivity = Float

    def __init__(self, device_index, sensitivity=1.0, sinus_key=None, name=None):
        self.sensitivity = sensitivity
        super().__init__(device_context='Open', device_index=device_index, sinus_key=sinus_key, name=name)
        self._build_traits()
        self._update_traits()

    def __get_dict_attribute(self, attribute):
        d = {}
        keys = SINUS.Get(self._sinus_key, attribute)
        for k in keys:
            v = SINUS.Get(self._sinus_key, attribute, k)
            d.update({k: v})
        return d

    def _build_readonly_traits(self):
        # here we only build the 'BUFFER' dictionary
        props = SINUS.Get(self._sinus_key)
        if 'BUFFER' in props:
            self.add_trait('BUFFER', self.__get_dict_attribute(attribute='BUFFER'))
        if 'TEDSData' in props:
            self.add_trait('TEDSData', self.__get_dict_attribute(attribute='TEDSData'))

    def _update_readonly_traits(self):
        if hasattr(self, 'BUFFER'):
            self.BUFFER = self.__get_dict_attribute(attribute='BUFFER')
        if hasattr(self, 'TEDSData'):
            self.TEDSData = self.__get_dict_attribute(attribute='TEDSData')
        elif 'TEDSData' in SINUS.Get(self._sinus_key):
            self.add_trait('TEDSData', self.__get_dict_attribute(attribute='TEDSData'))

    # no context because this may get called often
    def get_read_ptr_pos(self):
        return SINUS.GetByIndex(int(self.BUFFER['BufferIndex']), 1)

    # no context because this may get called often
    def get_write_ptr_pos(self):
        return SINUS.GetByIndex(int(self.BUFFER['BufferIndex']), 0)

    def get_ptr_pos(self):
        idx = int(self.BUFFER['BufferIndex'])
        return SINUS.GetByIndex(idx, 0), SINUS.GetByIndex(idx, 1)


class SinusPCICard(SinusObject):
    """Object for handling PCI devices such as the Apollo Light (or PCI cards).

    This class provides access to the PCI devices, and includes the device index and serial number as attributes.

    Parameters
    ----------
    device_index : int
        The index of the device.

    Attributes
    ----------
    name : str
        The name of the device.
    device_index : int
        The index of the device.
    serial : str
        The serial number of the PCI device.

    Notes
    -----
    Most attributes are built automatically during device initilization when the class is instantiated.
    This includes properties such as:

    :attr:`Mode`:
        DSP/Working Mode name (influences the settable values of the samplerate of the device channels).
        Typically, the settable values are {'HarmEnv_102400', 'HarmEnv_204800', 'HarmEnv_96000', 'HarmEnv_88200'}.
        The 'HarmEnv_96000' mode will allow sample rates such as 96 kHz, 48 kHz, 24 kHz, ...
    :attr:`VerbosityLevel`:
        Sets the amount of output that is written to the driver log files. Settable values are
        {'Quiet', 'FatalError', 'Error', 'SevereWarning','Warning','Info', 'DebugMessage', 'Diagnostic'}
    :attr:`BlockCount`:
        Number of blocks buffered by the driver. Settable values are usually in the range of [1, 16384].

    A full list of initialized attributes can be seen with

    >>> SINUS.SelectDevice(0)
    >>> apollo = SinusPCICard(device_index=0)
    >>> print(apollo._settable_attr)
    """

    serial = Str
    sync_order = Either(Tuple, None)
    __analog_inputs = List(SinusAnalogChannel)
    __analog_outputs = List(SinusAnalogChannel)
    __adc_to_dac = List(SinusADCToDACChannel)

    def __init__(self, serial, sync_order=None, name=None, **kwargs):
        self.serial = serial
        if serial not in SINUS.device_index:
            raise SinusDeviceConnectionError(f'Serial number {serial} not found. Device may not be connected.')
        device_index = SINUS.device_index[serial]
        name = name if name else type(self).__name__ + f'_{device_index:02d}'
        super().__init__(device_context='Config', device_index=device_index, sinus_key='Device', name=name)
        self.logger.setLevel('DRIVER')
        with self.logger.driver('Initializing ...'):
            # set the device to the correct mode

            sync_id = 0 if sync_order is None else sync_order.index(self.serial)
            # if device not in slave mode
            if sync_id == 0 and sync_order is not None:
                sync_string = ' '.join([str(i) for i in [SINUS.device_index[s] for s in sync_order[1:]]])
                with SinusDeviceContext('Config', device_index):
                    if SINUS.Set('Device', 'SyncWithDevices', sync_string) != 0:
                        raise SinusSynchronizationError(
                            f"Could not set sync string '{sync_string}' of PCI card \
                        {device_index} (SN:{serial})"
                        )

            self._build_traits()
            # set the device to the correct mode
            # mode might be part of **kwargs -> superseeds fs
            for attribute, value in kwargs.items():
                if attribute != 'fs':
                    setattr(self, attribute, value)
                elif ('fs' in kwargs) and ('Mode' not in kwargs) and (kwargs['fs'] is not None):
                    mode = self._validate_device_mode(kwargs['fs'])
                    self.Mode = mode
            self.set_settings('Mode')
            self._update_traits()

            if sync_id == 0:
                with SinusDeviceContext('Open', device_index):
                    opts = SINUS.Get()
                    num_inputs = sum(1 for _ in filter(lambda x: x.startswith('AnalogInput'), opts))
                    num_outputs = sum(1 for _ in filter(lambda x: x.startswith('AnalogOutput'), opts))
                    num_adc_to_dac = sum(1 for _ in filter(lambda x: x.startswith('ADCToDAC'), opts))

                    for i in range(num_inputs):
                        self.logger.driver(f'Instantiating AnalogInput_{sync_id * num_inputs + i + 1:03d} ...')
                        self.__analog_inputs.append(
                            SinusAnalogChannel(
                                device_index=device_index, name=f'AnalogInput_{sync_id * num_inputs + i + 1:03d}'
                            )
                        )
                    for i in range(num_outputs):
                        self.__analog_outputs.append(
                            SinusAnalogChannel(
                                device_index=device_index, name=f'AnalogOutput_{sync_id * num_outputs + i + 1:03d}'
                            )
                        )
                    for i in range(num_adc_to_dac):
                        self.__adc_to_dac.append(
                            SinusADCToDACChannel(
                                device_index=device_index, name=f'ADCToDAC_{sync_id * num_adc_to_dac + i + 1:03d}'
                            )
                        )

    def _validate_device_mode(self, fs):
        device_modes = SINUS.Get('Device', 'Mode', 'SetValues')
        set_values_mode = [float(fs_mode.strip('HarmEnv_')) for fs_mode in device_modes]
        divisible = [fs_mode % fs == 0.0 for fs_mode in set_values_mode]
        if any(divisible):
            return device_modes[divisible.index(True)]
        else:
            raise ValueError(f'unsupported fs {fs}! Supported values are multiples of {set_values_mode}')


SAFETY_DISTANCE = 0


class SinusStreamContext(BasicObject, ContextDecorator):
    """Context manager that selects the chosen Sinus device and starts the stream.

    Can be passed on to the `play`and `record` functions of `SinusDevice` instances,
    which will wait until `self.start` is called, to ensure synchronization.

    Parameters
    ----------
    channels
        The channels to open and operate on.
    """

    channels = List
    event = Either(Instance(Event), None)
    on_cue = Bool
    sync_start = Bool
    num_threads = Int
    barrier = Instance(Barrier)

    def __init__(self, channels=None, on_cue=False, sync_start=False, num_threads=0):
        super().__init__()
        if channels is None:
            channels = []
        self.channels = channels
        self.event = Event()
        self.on_cue = on_cue
        self.sync_start = sync_start
        self.num_threads = num_threads
        if num_threads > 0:
            self.barrier = Barrier(num_threads, action=self.start)

    def __enter__(self):
        try:
            self.enable_channels()
        except SinusDeviceStatusError as err:
            self.logger.error(err)
        return self

    def __exit__(self, *exc):
        self.stop()
        return False

    def _set_channel(self, ch, value):
        ch.ENABLED = value
        ch.set_settings()

    def enable_channels(self):
        """Enables all channels."""
        for channel in self.channels:
            self._set_channel(channel, '1')

    def start(self):
        self.logger.debug('Start Device Stream...')
        if SINUS.Get('Device', 'Status', 'DeviceStatus')[1] != 'ISR':
            r = SINUS.Start()  # order matters for pointer calculation!
            self.logger.debug(f'Started Device Stream with return code {r}.')
        else:
            self.logger.debug('Device Stream already running.')
        self.event.set()

    def stop(self):
        self.logger.debug('Stop Device Stream...')
        if SINUS.Get('Device', 'Status', 'DeviceStatus')[1] == 'ISR':
            r = SINUS.Stop()  # order matters for pointer calculation!
            self.logger.debug(f'Stopped Device Stream with return code {r}.')
        self.logger.debug('Device Stream already stopped.')
        self.event.clear()


class SinusStream(BasicObject):
    # self-written mid-level functions
    def _calc_pointer_distance(self, read_pointer_pos, write_pointer_pos, block_count):
        """Calculates distance between read and write pointer in channel buffer."""
        return (write_pointer_pos + block_count - read_pointer_pos) % block_count

    def _read_buffer(self, data, num_blocks, rp, buffer_indices):
        """Read samples from the ring buffers.

        This function is for synchronized channels only. Each channel has its own ring buffer.

        Parameters
        ----------
        data : np.ndarray
            Data array of shape (number of samples, number of channels)
        num_samples : int
            Number of samples to read from the buffers.
        num_blocks : int
            Number of blocks to read.
        rp : int
            Read pointer position.
        buffer_indices : list
            List of buffer indices for each channel.

        """
        for c, bi in enumerate(buffer_indices):
            data[:, c] = SINUS.GetBlockDataByIndex(bi, rp, num_blocks)

    def _flush_buffer(self, buffer_indices, nblocks, spb):
        """Flushes the buffer, i.e. writes zeros."""
        for buffer_index in buffer_indices:
            r = SINUS.SetBlockDataByIndex(buffer_index, 0, nblocks, np.zeros(spb * nblocks, dtype=np.int32).tobytes())
            self.logger.debug(f'flush buffer {buffer_index} with {nblocks} blocks (return code {r})')

    def _fill_buffer(self, buffer_indices, nblocks, signal, pos):
        """Fills the buffer with a given signal."""
        for i, buffer_index in enumerate(buffer_indices):
            r = SINUS.SetBlockDataByIndex(buffer_index, pos, nblocks, signal[i].astype(np.int32).tobytes())
            self.logger.debug(
                f'fill buffer {buffer_index} with {nblocks} blocks \
                                (size {signal[i].shape}) at {pos} (return code {r})'
            )

    def _get_pointer_position(self, buffer_index):
        return SINUS.GetByIndex(buffer_index, 1), SINUS.GetByIndex(buffer_index, 0)

    def _analog_output_calibration_factor(self, channels):
        """Reads fatory-defined calbiration factors for the output channels from the device."""
        fac = np.ones(len(channels), dtype=np.double)
        for i, ch in enumerate(channels):
            channel_props = SINUS.Get(ch._sinus_key)
            if 'CalibData' in channel_props:
                value = SINUS.Get(ch._sinus_key, 'CalibData', 'DACSlope')
                if value != '0':
                    fac[i] = np.double(value)
                else:
                    fac[i] = np.double(SINUS.Get(ch._sinus_key, 'CalibData', 'DACSlopeDefault'))
        return fac

    def _analog_input_calibration_factor(self, channels):
        """Reads fatory-defined calbiration factors for the input channels from the device."""
        fac = np.zeros(len(channels))
        for i, ch in enumerate(channels):
            channel_props = SINUS.Get(ch._sinus_key)
            fac[i] = float(SINUS.Get(ch._sinus_key, 'CalibData', 'ADCSlope')) if 'CalibData' in channel_props else 1
            fac[i] *= 10 ** (float(SINUS.Get(ch.name, 'GAIN', 'CurrentValue')) / -20) if 'GAIN' in channel_props else 1
            fac[i] /= ch.sensitivity
        return fac

    def _pad_signal(self, signal, samples_per_block):
        """Pads signal with zeros to a length that is a multiple of the block size.

        Signal is of shape (number of channels, number of samples)
        """
        if signal.shape[1] % samples_per_block != 0:
            pad = samples_per_block - signal.shape[1] % samples_per_block
            signal = pad(signal, ((0, 0), (0, pad)), 'constant')
        return signal

    def _extend_and_calibrate_signal(self, signal, channels):
        """Extends signal to a length that is a multiple of the block size and calibrates it.

        Signal is of shape (number of channels, number of samples)
        """
        if signal.ndim == 1:
            signal = signal[np.newaxis, :]
        return signal / self._analog_output_calibration_factor(channels)[:, np.newaxis]

    def _output_thread(self, channels, signal, context):
        """Writes the given signal to the buffers of the given channels. Can be used for parallel threading."""
        blocks_played = 0
        fs = int(channels[0].SampleRate)
        samples_per_block = int(channels[0].BUFFER['SamplesPerBlock'])
        block_count = int(SINUS.Get('Device', 'BlockCount', 'CurrentValue'))
        buffer_indices = [int(ch.BUFFER['BufferIndex']) for ch in channels]
        devstatus = SINUS.Get('Device', 'Status', 'DeviceStatus')[1]
        self.logger.debug(f'device status: {devstatus}')
        if devstatus == 'ISR':
            # output read pointer and input write pointer are the same!
            self._flush_buffer(buffer_indices, block_count, samples_per_block)
            read = (channels[0].get_read_ptr_pos() + SAFETY_DISTANCE) % block_count  # insert two blocks later
        else:
            read = SAFETY_DISTANCE  # delay needed! otherwise we read from buffer before writing
        # prepare output
        signal = self._extend_and_calibrate_signal(signal, channels)
        blocks_total = int(np.ceil(signal.shape[1] / samples_per_block))
        if blocks_total <= block_count:
            self._fill_buffer(buffer_indices, blocks_total, self._pad_signal(signal, samples_per_block), read)
        else:
            pre_fill = (block_count - SAFETY_DISTANCE) * samples_per_block
            self._fill_buffer(buffer_indices, block_count - SAFETY_DISTANCE, signal[:, :pre_fill], read)
            bi = pre_fill

        # start streaming or wait on cue
        if context.sync_start is True:
            self.logger.debug('output barrier reached')
            context.barrier.wait()
        elif context.on_cue:
            self.logger.debug('output wait on cue')
            context.event.wait()
        else:
            self.logger.debug('output normal context start')
            context.start()
        self.logger.debug(f'insert data at {read}')
        self.logger.debug(f'read pointer at {channels[0].get_read_ptr_pos()}')
        time.sleep((SAFETY_DISTANCE * samples_per_block) / fs)
        self.logger.driver('Play output signal...')
        self.logger.debug(f'read pointer at {channels[0].get_read_ptr_pos()}')
        self.logger.debug(f'play blocks_total: {blocks_total}')
        while context.event.is_set() and blocks_played < blocks_total:
            write, rp = channels[0].get_ptr_pos()
            pd = self._calc_pointer_distance(read, rp, block_count)
            if pd > 0:
                blocks_played += pd
                read = rp
                pd = self._calc_pointer_distance(write, read, block_count)
                if (blocks_total > block_count) and pd > SAFETY_DISTANCE:  # write new data to buffer
                    if bi < signal.shape[1]:
                        bi_end = min(bi + (pd - SAFETY_DISTANCE) * samples_per_block, signal.shape[1])
                        self._fill_buffer(
                            buffer_indices,
                            int(np.ceil((bi_end - bi) / samples_per_block)),
                            self._pad_signal(signal[:, bi:bi_end], samples_per_block),
                            write,
                        )
                        bi = bi_end
                    else:  # end of signal reached, fill buffer with zeros
                        self._fill_buffer(
                            buffer_indices, 1, np.zeros((len(channels), samples_per_block), dtype=np.float64), write
                        )
                    self.logger.debug(f'output read/write/index/blocks: {read}/{write}/{bi}/{blocks_played})')
                else:
                    self.logger.debug(f'output read pointer at: {read}), played {blocks_played} blocks')
            self.logger.debug(blocks_played)
        self.logger.driver('Stopped playing output signal.')
        self._flush_buffer(buffer_indices, block_count, samples_per_block)

    def _input_thread(self, channels, numsamples, queue, context):
        """Records input from the buffers of the given channels. Can be used for parallel threading."""
        self._max_pdiff = 0  # monitor max pointer distance
        block_count = int(SINUS.Get('Device', 'BlockCount', 'CurrentValue'))
        fs = int(channels[0].SampleRate)
        n_channels = len(channels)
        samples_per_block = int(channels[0].BUFFER['SamplesPerBlock'])
        [int(ch.BUFFER['BufferIndex']) for ch in channels]
        if numsamples is not None:
            max_qsize = numsamples // samples_per_block + 1
        self.logger.driver('Analog input ready!')
        if context.sync_start is True:
            self.logger.debug('input barrier reached')
            context.barrier.wait()
            read = SAFETY_DISTANCE
            time.sleep((read * samples_per_block) / fs)
            write, _ = channels[0].get_ptr_pos()
        elif context.on_cue:
            self.logger.debug('input wait on cue...')
            context.event.wait()
            write, read = channels[0].get_ptr_pos()
        else:
            self.logger.debug('input normal context start')
            context.start()
            write, read = channels[0].get_ptr_pos()
        self.logger.driver('Record...')
        while context.event.is_set():
            pd = self._calc_pointer_distance(read, write, block_count)
            if pd >= 1:
                self._max_pdiff = max(self._max_pdiff, pd)
                self._pdiff_in = pd
                self.logger.debug(f'input pointer distance: {pd} ({write}, {read})')
                data = np.empty((samples_per_block, n_channels), dtype=np.float64)

                for c, ch in enumerate(channels):
                    buffer_index = int(ch.BUFFER['BufferIndex'])
                    data[:, c] = SINUS.GetBlockDataByIndex(buffer_index, read, 1)

                # data = SINUS_STREAM._read_buffer(data, 1, read, buffer_indices)
                queue.put(data)
                self.logger.debug(f'Queue size: {queue.qsize()}')
                if numsamples is not None:
                    if queue.qsize() == max_qsize:
                        break
            write, read = channels[0].get_ptr_pos()
        self.logger.driver('Stopped recording.')
        self._validate_max_pointer_distance(block_count)

    def _validate_max_pointer_distance(self, block_count):
        if (self._max_pdiff > block_count // 2) and self._max_pdiff < int(block_count * 0.95):
            self.logger.warning(
                f'Maximum pointer distance: {self._max_pdiff} in ring buffer with size {block_count}.\
                                  Data loss possible!'
            )
        elif self._max_pdiff >= int(block_count * 0.95):
            self.logger.critical(
                f'Maximum pointer distance: {self._max_pdiff} in ring buffer with size {block_count}.\
                                Data loss probable!'
            )

    def _init_stream(self, channels):
        """Checks channels before streams are initialized."""
        for ch in channels:
            if ch.BUFFER['BufferIndex'] == '-1':
                raise SinusPlayRecError(f'Channel buffer not initialized! Channel {ch.name} has no buffer index.')
            if ch.BUFFER['SamplesPerBlock'] != channels[0].BUFFER['SamplesPerBlock']:
                raise SinusPlayRecError('Not all channels have the same samples per block!')

    @contextmanager
    def _stream(self, stream_func, channels):
        """Creates a stream for parallel threading using the given function, which is then executed in parallel."."""
        try:
            self._init_stream(channels)
            stream = Thread(target=stream_func)
            stream.start()
            yield
        except Exception as err:
            self.logger.error(f'{err}')
        finally:
            stream.join()
            self.logger.driver('End of stream.')

    @contextmanager
    def play(self, signal, channels, on_cue, context=None):
        """
        Plays the given signal using parallel threading.

        This is a low-level class not intended for the user. It is accessed by high-level device classes
        such as :class:`Apollo`.
        """
        with self.logger.driver('Playing signal ...'):
            if context is None:  # creates its own context
                context = SinusStreamContext(channels, on_cue=on_cue)
                stream_func = partial(self._output_thread, channels, signal, context)
                with context:
                    with self._stream(stream_func, channels):
                        yield context
            else:  # if outer context is given, we don't use it!
                stream_func = partial(self._output_thread, channels, signal, context)
                with self._stream(stream_func, channels):
                    yield context

    @contextmanager
    def record(self, cal_obj, channels, numsamples=None, on_cue=False, context=None):
        """
        Records input from the given channels using parallel threading.

        This is a low-level class not intended for the user. It is accessed by high-level device classes
        such as :class:`Apollo`.
        """
        queue = Queue()
        with self.logger.driver('Recording signal ...'):
            if context is None:  # creates its own context
                context = SinusStreamContext(channels, on_cue=on_cue)
                stream_func = partial(self._input_thread, channels, numsamples, queue, context)
                with context:
                    with self._stream(stream_func, channels):
                        yield context
            else:  # if outer context is given, we don't use it!
                stream_func = partial(self._input_thread, channels, numsamples, queue, context)
                with self._stream(stream_func, channels):
                    yield context
        cal_obj.data = np.concatenate(list(queue.queue), axis=0).T
        cal_fac = self._analog_input_calibration_factor(channels)[:, np.newaxis]
        if numsamples is not None:
            cal_obj.data = cal_obj.data[:, : int(numsamples)]
        cal_obj.data *= cal_fac

    @contextmanager
    def calibrate(self, cal_obj, calibvalue, f, channel, numsamples=None, on_cue=False, context=None):
        channel[0].sensitivity = 1.0  # channel returns voltage
        with cal_obj.record(channels=channel, numsamples=numsamples, on_cue=on_cue, context=context) as ctx:
            yield ctx
        cal_obj.data = self.calib_filter(cal_obj.data, f, float(channel[0].SampleRate))
        cal = (np.sqrt(np.mean(cal_obj.data**2, axis=1)) / calibvalue)[0]
        self.logger.driver(f'new sensitivity={cal} V/Pa for channel {channel[0].name}')
        channel[0].sensitivity = cal

    def calib_filter(self, data, f, fs):
        return dsp.filter.butterworth(
            Signal(data, sampling_rate=fs), N=3, frequency=(f / 2 ** (1 / 6), f * 2 ** (1 / 6)), btype='bandpass'
        ).time


SINUS_STREAM = SinusStream()
