"""Contains driver classes for serial port communication."""

from contextlib import contextmanager
from functools import wraps

from serial import Serial
from serial.serialutil import SerialException, Timeout
from traits.api import Int, Trait

from tapy.core.base import BasicObject
from tapy.core.config import config


class SerialCommunicationError(Exception):
    """Exception raised when there is an error in serial communication."""


def timed_retry(method):
    @wraps(method)
    def _impl(self, *args, **kwargs):
        timeout = Timeout(self.maxtime)
        for _ in range(self.maxtries):
            with self._exception_handler():
                if timeout.expired():
                    break
                return method(self, *args, **kwargs)
        if timeout.expired():
            self.logger.warning(f'Timeout ({self.maxtime}s)!')
        else:
            self.logger.warning(f'Maximum number of tries ({self.maxtries}) exceeded!')

    return _impl


class SerialObject(BasicObject):
    """Base class for serial port communication.

    This class provides a base for communicating with devices over a serial port. It handles the initialization and
    configuration of the serial port, as well as error handling and logging. Subclasses can override or extend this
    class to implement specific serial communication protocols or behaviors.


    Parameters
    ----------
    port: str, optional
        The name of the serial port to use. If not provided, a default port will be used based on the platform.
    baudrate: int, optional
        The baud rate of the connection. Defaults to 9600. See `pyserial.Serial` for all admissible values.
    name: str, optional
        The name of the object. This will be used for logging purposes.


    Attributes
    ----------
    maxtries : int
        The maximum number of times to try a serial communication operation before giving up.
    maxtime : int
        The maximum amount of time to wait for a serial communication operation to complete before giving up.
    serial : Serial
        The `pyserial.Serial` object representing the serial port.
    """

    serial = Trait(Serial)
    maxtries = Int(5)
    maxtime = Int(5)

    def __init__(self, port=None, baudrate=9600, name=None):
        super().__init__(name)

        if port is None:
            if config.ON_LINUX:
                port = '/dev/ttyUSB0'
            elif config.ON_MACOS:
                port = '/dev/tty.usbserial'
            elif config.ON_WINDOWS:
                port = 'COM1'
            else:
                raise NotImplementedError('Platform not supported.')

        with self.logger.driver(f'Opening serial port {port} ...'):
            with self._exception_handler():
                self.serial = Serial(port, baudrate=baudrate)

    @contextmanager
    def _exception_handler(self):
        try:
            yield
        except SerialException as err:
            self.logger.error(err)
            raise err
        except SerialCommunicationError as err:
            self.logger.driver(err)
            self.logger.driver('Retrying ...')
