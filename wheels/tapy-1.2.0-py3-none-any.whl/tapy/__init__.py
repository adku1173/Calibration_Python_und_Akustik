"""The TAPy package."""

from tapy.core.logger import configure_logger

configure_logger()
